import asyncio
import pygame

pygame.init()
s = pygame.display.set_mode((480, 800))
pygame.display.set_caption("WRAPPER ALIVE")
s.fill((0, 200, 0))
pygame.display.flip()

try:
    import game
    s.fill((200, 200, 0))
    pygame.display.set_caption("IMPORT RETURNED")
    pygame.display.flip()
except BaseException as e:
    s.fill((200, 0, 200))
    pygame.display.set_caption("IMPORT FAILED")
    pygame.display.flip()
    async def _hold():
        while True:
            await asyncio.sleep(1)
    asyncio.run(_hold())
