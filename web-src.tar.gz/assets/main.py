import asyncio
import pygame
import traceback

def _show_error(text):
    try:
        pygame.init()
        s = pygame.display.set_mode((480, 800))
        pygame.display.set_caption("BOOT ERROR")
        s.fill((0, 0, 0))
        try:
            font = pygame.font.Font(None, 22)
        except Exception:
            font = pygame.font.SysFont("monospace", 18)
        y = 8
        for line in text.split("\n")[:34]:
            try:
                surf = font.render(line[:72], True, (255, 90, 90))
                s.blit(surf, (8, y))
            except Exception:
                pass
            y += 22
            if y > 780:
                break
        pygame.display.flip()
    except Exception:
        pass

try:
    import game
except BaseException:
    _show_error(traceback.format_exc())
    async def _hold():
        while True:
            await asyncio.sleep(1)
    try:
        asyncio.run(_hold())
    except BaseException:
        pass
