import pygame
import sys
import os
import random
import json
import math
import asyncio

# 1. Initialize Pygame & Mixer
# Browser-audio fix (glitchy music): set the mixer params BEFORE
# pygame.init() so the mixer opens at the music's sample rate with
# a larger buffer. All audio is 48kHz except walk.ogg (44.1kHz),
# which SDL resamples. Bigger buffer = fewer underruns in browser.
pygame.mixer.pre_init(frequency=48000, size=-16, channels=2, buffer=8192)
pygame.init()
pygame.mixer.init(frequency=48000, size=-16, channels=2, buffer=8192)

# --- Settings & Save Data ---
SETTINGS_FILE = "id_settings.json"
platform_mode = "mobile"
pass_screen_timer = "ON"
music_on = "ON"
sfx_on = "ON"
movement_mode = "anywhere"
try:
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r") as f:
            data = json.load(f)
            platform_mode = data.get("platform_mode", "mobile")
            pass_screen_timer = data.get("pass_screen_timer", "ON")
            music_on = data.get("music_on", "ON")
            sfx_on = data.get("sfx_on", "ON")
            movement_mode = data.get("movement_mode", "anywhere")
except Exception:
    pass

def save_settings():
    try:
        with open(SETTINGS_FILE, "w") as f:
            json.dump({
                "platform_mode": platform_mode, 
                "pass_screen_timer": pass_screen_timer,
                "music_on": music_on,
                "sfx_on": sfx_on,
                "movement_mode": movement_mode
            }, f)
    except Exception:
        pass

# --- Audio Loading (Background Music & SFX) ---
def update_music():
    try:
        if music_on == "ON":
            if not pygame.mixer.music.get_busy():
                pygame.mixer.music.play(-1)
            else:
                pygame.mixer.music.unpause()
        else:
            pygame.mixer.music.pause()
    except Exception:
        pass

try:
    if '__file__' in globals():
        bg_music_path = os.path.join(os.path.dirname(__file__), "Inverse_Dimensions_Backtrack.ogg")
        if os.path.exists(bg_music_path):
            pygame.mixer.music.load(bg_music_path)
            pygame.mixer.music.set_volume(0.4)
            if music_on == "ON":
                pygame.mixer.music.play(-1)
except Exception as e:
    print("Could not load background music:", e)

def load_sound(filename):
    try:
        if '__file__' in globals():
            path = os.path.join(os.path.dirname(__file__), filename)
            if os.path.exists(path):
                return pygame.mixer.Sound(path)
    except Exception:
        pass
    return None

btn_click1 = load_sound("ButtonClick1.ogg")
btn_click2 = load_sound("ButtonClick2.ogg")
start_click = load_sound("StartButtonClick.ogg")

def play_normal_click():
    if sfx_on == "OFF": return
    sounds = [s for s in (btn_click1, btn_click2) if s]
    if sounds:
        random.choice(sounds).play()

def play_start_click():
    if sfx_on == "OFF": return
    if start_click:
        start_click.play()
    else:
        play_normal_click()

walk_sound = None
try:
    if '__file__' in globals():
        for ext in ["ogg", "wav", "mp3"]:
            snd_path = os.path.join(os.path.dirname(__file__), f"walk.{ext}")
            if os.path.exists(snd_path):
                walk_sound = pygame.mixer.Sound(snd_path)
                break
except Exception as e:
    print("Could not load walk audio:", e)

def play_walk_sound():
    if sfx_on == "OFF": return
    if walk_sound:
        try:
            walk_sound.stop()  
            walk_sound.play()  
        except Exception:
            pass

# Start Android text manager safely
pygame.key.stop_text_input()
pygame.key.start_text_input()

if sys.platform == "emscripten":
    screen = pygame.display.set_mode((480, 800))
else:
    screen = pygame.display.set_mode((0, 0))
screen_width, screen_height = screen.get_size()
pygame.display.set_caption("Inverse Dimensions")

# --- UI Scaling Engine ---
COLS, ROWS = 7, 11

def init_geometry():
    global top_padding, bottom_padding, available_height, cell_size, grid_offset_x, grid_offset_y
    global home_btn_size, home_btn_rect, setup_btn_w, setup_btn_gap, setup_total_w, setup_start_x, setup_btn_h
    global wall_tool_rect, throne_tool_rect, crate_tool_rect, random_tool_rect
    global ctrl_btn_w, ctrl_btn_gap, ctrl_total_w, ctrl_start_x, ctrl_btn_h, center_y_bottom
    global guess_btn_rect, end_turn_btn_rect, swap_portal_btn_rect, use_heart_btn_rect
    global confirm_btn_width, confirm_btn_height, confirm_btn_rect
    global p1_input_rect, p1_confirm_rect, p2_input_rect, p2_confirm_rect, pass_btn_rect, restart_btn_rect
    global rules_btn_rect, rules_prev_rect, rules_next_rect
    global enable_mem_rect, disable_mem_rect, view_map_btn_rect, return_win_rect, exit_game_rect
    global modal_width, modal_height, modal_rect, modal_close_rect
    global font_tiny, font_small, font_medium, font_large
    global home_menu_rects, vis_cols, vis_rows
    
    if platform_mode == "mobile":
        top_padding = int(screen_height * 0.16)
        bottom_padding = int(screen_height * 0.32)
        base_ui_w = screen_width
        f_mult = 1.0
        vis_cols, vis_rows = 7, 11
    else:
        top_padding = int(screen_height * 0.05)
        bottom_padding = int(screen_height * 0.15)
        base_ui_w = min(screen_width, int(screen_height * 0.8))
        f_mult = 0.75
        vis_cols, vis_rows = 11, 7

    available_height = screen_height - top_padding - bottom_padding
    cell_size = min(screen_width // vis_cols, available_height // vis_rows)
    grid_offset_x = (screen_width - (cell_size * vis_cols)) // 2
    grid_offset_y = top_padding + (available_height - (cell_size * vis_rows)) // 2

    home_btn_size = int(base_ui_w * 0.12 * f_mult)
    if platform_mode == "desktop": home_btn_size = min(home_btn_size, 60)
    home_btn_rect = pygame.Rect(screen_width - home_btn_size - 15, 15, home_btn_size, home_btn_size)

    setup_btn_w = int(base_ui_w * 0.22)
    setup_btn_gap = int(base_ui_w * 0.02)
    setup_total_w = (4 * setup_btn_w) + (3 * setup_btn_gap)
    setup_start_x = (screen_width - setup_total_w) // 2
    setup_btn_h = int(screen_height * 0.06 * f_mult)

    wall_tool_rect = pygame.Rect(setup_start_x, screen_height - bottom_padding + 15, setup_btn_w, setup_btn_h)
    throne_tool_rect = pygame.Rect(setup_start_x + setup_btn_w + setup_btn_gap, screen_height - bottom_padding + 15, setup_btn_w, setup_btn_h)
    crate_tool_rect = pygame.Rect(setup_start_x + 2 * (setup_btn_w + setup_btn_gap), screen_height - bottom_padding + 15, setup_btn_w, setup_btn_h)
    random_tool_rect = pygame.Rect(setup_start_x + 3 * (setup_btn_w + setup_btn_gap), screen_height - bottom_padding + 15, setup_btn_w, setup_btn_h)

    ctrl_btn_w = setup_btn_w
    ctrl_btn_gap = setup_btn_gap
    ctrl_total_w = setup_total_w
    ctrl_start_x = setup_start_x
    ctrl_btn_h = int(screen_height * 0.07 * f_mult)
    center_y_bottom = screen_height - (bottom_padding // 2)

    guess_btn_rect = pygame.Rect(ctrl_start_x, center_y_bottom - ctrl_btn_h // 2, ctrl_btn_w, ctrl_btn_h)
    end_turn_btn_rect = pygame.Rect(ctrl_start_x + ctrl_btn_w + ctrl_btn_gap, center_y_bottom - ctrl_btn_h // 2, ctrl_btn_w, ctrl_btn_h)
    swap_portal_btn_rect = pygame.Rect(ctrl_start_x + 2 * (ctrl_btn_w + ctrl_btn_gap), center_y_bottom - ctrl_btn_h // 2, ctrl_btn_w, ctrl_btn_h)
    use_heart_btn_rect = pygame.Rect(ctrl_start_x + 3 * (ctrl_btn_w + ctrl_btn_gap), center_y_bottom - ctrl_btn_h // 2, ctrl_btn_w, ctrl_btn_h)

    confirm_btn_width = int(base_ui_w * 0.75)
    confirm_btn_height = int(screen_height * 0.07 * f_mult)
    confirm_btn_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, screen_height - bottom_padding + 15 + setup_btn_h + 15, confirm_btn_width, confirm_btn_height)

    p1_input_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, int(screen_height * 0.4), confirm_btn_width, confirm_btn_height)
    p1_confirm_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, int(screen_height * 0.6), confirm_btn_width, confirm_btn_height)
    p2_input_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, int(screen_height * 0.4), confirm_btn_width, confirm_btn_height)
    p2_confirm_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, int(screen_height * 0.6), confirm_btn_width, confirm_btn_height)

    pass_btn_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, screen_height // 2, confirm_btn_width, confirm_btn_height)

    rules_btn_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, screen_height - bottom_padding + 30, confirm_btn_width, confirm_btn_height)
    rules_prev_rect = pygame.Rect(screen_width // 2 - int(confirm_btn_width * 0.5), screen_height - bottom_padding + 10, int(confirm_btn_width * 0.45), confirm_btn_height)
    rules_next_rect = pygame.Rect(screen_width // 2 + int(confirm_btn_width * 0.05), screen_height - bottom_padding + 10, int(confirm_btn_width * 0.45), confirm_btn_height)

    enable_mem_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, screen_height // 2, confirm_btn_width, confirm_btn_height)
    disable_mem_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, screen_height // 2 + confirm_btn_height + 20, confirm_btn_width, confirm_btn_height)

    view_map_btn_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, screen_height // 2 + 30, confirm_btn_width, confirm_btn_height)
    restart_btn_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, screen_height // 2 + 30 + confirm_btn_height + 20, confirm_btn_width, confirm_btn_height)
    return_win_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, screen_height - confirm_btn_height * 2 - 30, confirm_btn_width, confirm_btn_height)
    exit_game_rect = pygame.Rect(screen_width // 2 - confirm_btn_width // 2, screen_height - confirm_btn_height - 15, confirm_btn_width, confirm_btn_height)

    modal_width = int(base_ui_w * 0.85)
    modal_height = int(screen_height * 0.45) if platform_mode == "mobile" else int(screen_height * 0.55)
    modal_rect = pygame.Rect(screen_width // 2 - modal_width // 2, screen_height // 2 - modal_height // 2, modal_width, modal_height)
    modal_close_rect = pygame.Rect(modal_rect.centerx - int(confirm_btn_width * 0.4), modal_rect.bottom - int(confirm_btn_height * 1.3), int(confirm_btn_width * 0.8), confirm_btn_height)

    hm_w = int(base_ui_w * 0.6)
    hm_h = int(screen_height * 0.08 * f_mult)
    start_y = screen_height // 2 - (hm_h * 5 + 4 * 15) // 2 + 50
    home_menu_rects = {
        "New Game": pygame.Rect(screen_width // 2 - hm_w // 2, start_y, hm_w, hm_h),
        "Load Game": pygame.Rect(screen_width // 2 - hm_w // 2, start_y + (hm_h + 15), hm_w, hm_h),
        "Game Rules": pygame.Rect(screen_width // 2 - hm_w // 2, start_y + 2 * (hm_h + 15), hm_w, hm_h),
        "Settings": pygame.Rect(screen_width // 2 - hm_w // 2, start_y + 3 * (hm_h + 15), hm_w, hm_h),
        "Close Game": pygame.Rect(screen_width // 2 - hm_w // 2, start_y + 4 * (hm_h + 15), hm_w, hm_h)
    }

    font_path = os.path.join(os.path.dirname(__file__), "CormorantGaramond-VariableFont_wght.ttf") if '__file__' in globals() else "CormorantGaramond-VariableFont_wght.ttf"
    
    sz_t = int(base_ui_w * 0.035 * f_mult)
    sz_s = int(base_ui_w * 0.04 * f_mult)
    sz_m = int(base_ui_w * 0.05 * f_mult)
    sz_l = int(base_ui_w * 0.08 * f_mult)

    try:
        font_tiny = pygame.font.Font(font_path, sz_t)
        font_small = pygame.font.Font(font_path, sz_s)
        font_medium = pygame.font.Font(font_path, sz_m)
        font_large = pygame.font.Font(font_path, sz_l)
    except Exception:
        font_tiny = pygame.font.SysFont("serif", sz_t)
        font_small = pygame.font.SysFont("serif", sz_s)
        font_medium = pygame.font.SysFont("serif", sz_m)
        font_large = pygame.font.SysFont("serif", sz_l)

def get_cell_rect(c, r):
    if platform_mode == "desktop":
        vx, vy = r, c
    else:
        vx, vy = c, r
    tx = grid_offset_x + vx * cell_size
    ty = grid_offset_y + vy * cell_size
    return tx, ty

def get_cell_center(c, r):
    tx, ty = get_cell_rect(c, r)
    return tx + cell_size // 2, ty + cell_size // 2

def get_grid_from_screen(pos_x, pos_y):
    vx = (pos_x - grid_offset_x) // cell_size
    vy = (pos_y - grid_offset_y) // cell_size
    if platform_mode == "desktop":
        return vy, vx
    else:
        return vx, vy

def load_and_scale_sprite(filename, size_multiplier=0.8):
    try:
        if '__file__' in globals():
            path = os.path.join(os.path.dirname(__file__), filename)
            if os.path.exists(path):
                img = pygame.image.load(path).convert_alpha()
                return pygame.transform.scale(img, (int(cell_size * size_multiplier), int(cell_size * size_multiplier)))
    except Exception:
        pass
    return None

ui_assets = {}
def load_all_sprites():
    global bluespace_sprite, redspace_sprite, yellowspace_sprite, memorized_bluespace_sprite, memorized_redspace_sprite
    global king_resting, warden_resting, wall_sprite
    global heart_crate_sprite, skull_crate_sprite, modal_heart_sprite, modal_skull_sprite, home_sprite
    global portal_frames, throne_sprite, throne_bad_sprite, empty_throne_sprite, king_bad, warden_bad
    global p1_setup_throne_sprites, p2_setup_throne_sprites, life_sprite, unlife_sprite, thronecrack_frames
    global heart_open_frames, skull_open_frames
    global bg_surface, logo_sprite, throne_icon_ui
    
    base_dir = os.path.dirname(__file__) if '__file__' in globals() else ""
    for name in ["button_standard.png", "button_important.png", "button_danger.png", 
                 "button_settings.png", "button_small.png", "panel_background.png"]:
        path = os.path.join(base_dir, name)
        if os.path.exists(path):
            ui_assets[name] = pygame.image.load(path).convert_alpha()
        else:
            ui_assets[name] = None

    bluespace_sprite = load_and_scale_sprite("bluespace.png", 1.0)
    redspace_sprite = load_and_scale_sprite("redspace.png", 1.0)
    yellowspace_sprite = load_and_scale_sprite("yellowspace.png", 1.0)
    memorized_bluespace_sprite = load_and_scale_sprite("memorized_bluespace.png", 1.0)
    memorized_redspace_sprite = load_and_scale_sprite("memorized_redspace.png", 1.0)

    king_resting = load_and_scale_sprite("king.png")
    warden_resting = load_and_scale_sprite("warden.png")
    wall_sprite = load_and_scale_sprite("wall.png")

    heart_crate_sprite = load_and_scale_sprite("heartcrate.png", 0.8)
    skull_crate_sprite = load_and_scale_sprite("skullcrate.png", 0.8)

    modal_crate_w = int(confirm_btn_width * 0.3)
    try:
        if '__file__' in globals():
            hc_path = os.path.join(os.path.dirname(__file__), "heartcrate.png")
            modal_heart_sprite = pygame.transform.scale(pygame.image.load(hc_path).convert_alpha(), (modal_crate_w, modal_crate_w)) if os.path.exists(hc_path) else None
            sc_path = os.path.join(os.path.dirname(__file__), "skullcrate.png")
            modal_skull_sprite = pygame.transform.scale(pygame.image.load(sc_path).convert_alpha(), (modal_crate_w, modal_crate_w)) if os.path.exists(sc_path) else None
    except Exception:
        modal_heart_sprite, modal_skull_sprite = None, None

    portal_frames = []
    try:
        if '__file__' in globals():
            p_path = os.path.join(os.path.dirname(__file__), "portal.png")
            if os.path.exists(p_path):
                sheet = pygame.image.load(p_path).convert_alpha()
                sheet_w, sheet_h = sheet.get_size()
                if sheet_h > 0:
                    for i in range(sheet_w // sheet_h):
                        frame_img = sheet.subsurface(pygame.Rect(i * sheet_h, 0, sheet_h, sheet_h))
                        portal_frames.append(pygame.transform.scale(frame_img, (int(cell_size * 0.8), int(cell_size * 0.8))))
    except Exception: pass

    throne_sprite = load_and_scale_sprite("throne.png") or load_and_scale_sprite("wardenthrone.png")
    throne_bad_sprite = load_and_scale_sprite("thronebad.png") or throne_sprite
    empty_throne_sprite = load_and_scale_sprite("emptythrone.png")
    king_bad = load_and_scale_sprite("kingbad.png")
    warden_bad = load_and_scale_sprite("wardenbad.png")

    if throne_sprite:
        throne_icon_ui = pygame.transform.scale(throne_sprite, (int(cell_size * 0.5), int(cell_size * 0.5)))
    else:
        throne_icon_ui = None

    p1_setup_throne_sprites = {
        "King": load_and_scale_sprite("kingthrone.png"),
        "Warden 1": load_and_scale_sprite("warden1throne.png"),
        "Warden 2": load_and_scale_sprite("warden2throne.png")
    }
    p2_setup_throne_sprites = {
        "King": load_and_scale_sprite("enemykingthrone.png"),
        "Warden 1": load_and_scale_sprite("enemywarden1throne.png"),
        "Warden 2": load_and_scale_sprite("enemywarden2throne.png")
    }

    life_sprite = load_and_scale_sprite("life.png", 0.75)
    unlife_sprite = load_and_scale_sprite("unlife.png", 0.75)

    thronecrack_frames = []
    try:
        if '__file__' in globals():
            tc_path = os.path.join(os.path.dirname(__file__), "thronecrack_sheet.png")
            if os.path.exists(tc_path):
                sheet = pygame.image.load(tc_path).convert_alpha()
                sheet_w, sheet_h = sheet.get_size()
                if sheet_h > 0:
                    tc_w = int(screen_width * 0.7)
                    for i in range(sheet_w // sheet_h):
                        frame_img = sheet.subsurface(pygame.Rect(i * sheet_h, 0, sheet_h, sheet_h))
                        thronecrack_frames.append(pygame.transform.scale(frame_img, (tc_w, tc_w)))
    except Exception: pass

    heart_open_frames = []
    skull_open_frames = []
    try:
        if '__file__' in globals():
            ho_path = os.path.join(os.path.dirname(__file__), "heartcrateopen.png")
            if os.path.exists(ho_path):
                sheet = pygame.image.load(ho_path).convert_alpha()
                sheet_w, sheet_h = sheet.get_size()
                if sheet_h > 0:
                    for i in range(sheet_w // sheet_h):
                        frame_img = sheet.subsurface(pygame.Rect(i * sheet_h, 0, sheet_h, sheet_h))
                        heart_open_frames.append(pygame.transform.scale(frame_img, (modal_crate_w, modal_crate_w)))
            
            so_path = os.path.join(os.path.dirname(__file__), "skullcrateopen.png")
            if os.path.exists(so_path):
                sheet = pygame.image.load(so_path).convert_alpha()
                sheet_w, sheet_h = sheet.get_size()
                if sheet_h > 0:
                    for i in range(sheet_w // sheet_h):
                        frame_img = sheet.subsurface(pygame.Rect(i * sheet_h, 0, sheet_h, sheet_h))
                        skull_open_frames.append(pygame.transform.scale(frame_img, (modal_crate_w, modal_crate_w)))
    except Exception: pass

    home_sprite = None
    try:
        if '__file__' in globals():
            h_path = os.path.join(os.path.dirname(__file__), "home.png")
            if os.path.exists(h_path):
                raw_h = pygame.image.load(h_path).convert_alpha()
                home_sprite = pygame.transform.scale(raw_h, (home_btn_size, home_btn_size))
    except Exception: pass

    logo_sprite = None
    try:
        if '__file__' in globals():
            logo_path = os.path.join(os.path.dirname(__file__), "logo.png")
            if os.path.exists(logo_path):
                raw_logo = pygame.image.load(logo_path).convert_alpha()
                lw, lh = raw_logo.get_size()
                max_w = int(screen_width * 0.9)
                if lw > max_w:
                    scale = max_w / float(lw)
                    logo_sprite = pygame.transform.scale(raw_logo, (int(lw * scale), int(lh * scale)))
                else: logo_sprite = raw_logo
    except Exception: pass

    bg_surface = pygame.Surface((screen_width, screen_height))
    bg_surface.fill((28, 28, 30))
    try:
        if '__file__' in globals():
            bg_path = os.path.join(os.path.dirname(__file__), "background.png")
            if os.path.exists(bg_path):
                raw_bg = pygame.image.load(bg_path).convert()
                bw, bh = raw_bg.get_size()
                scale = max(screen_width / bw, screen_height / bh)
                new_w, new_h = int(bw * scale), int(bh * scale)
                scaled_bg = pygame.transform.scale(raw_bg, (new_w, new_h))
                crop_x, crop_y = (new_w - screen_width) // 2, (new_h - screen_height) // 2
                bg_surface.blit(scaled_bg, (0, 0), pygame.Rect(crop_x, crop_y, screen_width, screen_height))
    except Exception: pass
    
    if 'p1_chars' in globals():
        p1_chars[0]["sprites"] = {"resting": king_resting}
        p1_chars[1]["sprites"] = {"resting": warden_resting}
        p1_chars[2]["sprites"] = {"resting": warden_resting}
    if 'p2_chars' in globals():
        p2_chars[0]["sprites"] = {"resting": king_bad}
        p2_chars[1]["sprites"] = {"resting": warden_bad}
        p2_chars[2]["sprites"] = {"resting": warden_bad}

init_geometry()

# --- Rules Text Data ---
rules_page_index = 0
rules_from_home = False
rules_pages = [
    [
        ("HOW TO PLAY", "title"),
        ("INVERSE DIMENSIONS", "subtitle"),
        ("GOAL", "subtitle"),
        ("- Capture all three enemy Thrones to win.", "text"),
        ("BASIC TURN FLOW", "subtitle"),
        ("- Start your turn.", "text"),
        ("- Move your King or one of your Wardens.", "text"),
        ("- Use available actions strategically.", "text"),
        ("- End your turn. Pass device to opponent.", "text"),
        ("KINGS", "subtitle"),
        ("- The King is your most important piece.", "text"),
        ("- Move, capture Thrones, open Crates, use Portals.", "text"),
        ("- If defeated by Warden or Skull Crate, the King", "text"),
        ("  is sent back to one of your active Thrones.", "text"),
    ],
    [
        ("WARDENS & THRONES", "title"),
        ("WARDENS", "subtitle"),
        ("- Wardens defend your territory.", "text"),
        ("- Move around the board & block enemy movement.", "text"),
        ("- Protect Thrones. If an enemy King encounters", "text"),
        ("  a Warden, the King is sent back to a Throne.", "text"),
        ("- Can be sacrificed when required by game rules.", "text"),
        ("THRONES", "subtitle"),
        ("- Each player begins with three Thrones.", "text"),
        ("- Capture all enemy Thrones to win.", "text"),
        ("- When a Throne is lost: The defending player", "text"),
        ("  loses that Throne, and a Warden may need to", "text"),
        ("  be sacrificed. Protect your Thrones carefully.", "text"),
    ],
    [
        ("CRATES", "title"),
        ("CRATES", "subtitle"),
        ("- Each player places 1 Heart and 1 Skull Crate.", "text"),
        ("- Hidden from the opponent during setup.", "text"),
        ("HEART CRATE", "subtitle"),
        ("- Opening grants a stored Heart.", "text"),
        ("- Acts as a Get Out of Jail Free card.", "text"),
        ("- When a Warden would send your King back,", "text"),
        ("  you may choose to use the Heart.", "text"),
        ("- If used: Heart is consumed, King remains, and", "text"),
        ("  the Warden is removed and returned normally.", "text"),
        ("SKULL CRATE", "subtitle"),
        ("- Immediately sends King back to a valid Throne.", "text"),
        ("- No damage is dealt (no health/HP in game).", "text"),
    ],
    [
        ("ADVANCED RULES", "title"),
        ("PORTALS", "subtitle"),
        ("- Portals allow rapid movement across the board.", "text"),
        ("- Escape danger, reach enemy territory, or", "text"),
        ("  launch surprise attacks.", "text"),
        ("SPACE MEMORY", "subtitle"),
        ("- When enabled: Previously visited enemy spaces", "text"),
        ("  remain visible.", "text"),
        ("- Helps players remember where they searched.", "text"),
        ("WINNING THE GAME", "subtitle"),
        ("- Capture all three enemy Thrones before", "text"),
        ("  your opponent captures yours.", "text"),
        ("- Strategic movement, memory, and careful use", "text"),
        ("  of Wardens, Portals, and Crates are the key.", "text"),
    ]
]


# --- Game States & Core Variables ---
game_state = "INTRO"
intro_start_time = 0
# Pygbag rule: declare ALL globals up top with the other globals.
# 'running' and 'clock' used to be first declared at line ~1267,
# right before main() -- pygbag's compiler missed them there.
running = True
clock = pygame.time.Clock()

next_state_after_pass = None
setup_mode = "wall"  
p1_setup_state = "random"
p2_setup_state = "random"
current_turn = 1     
actions_left = 6     
pass_screen_start_time = 0
PASS_DELAY_MS = 3000
final_winner = None

p1_lives = 3
p2_lives = 3
p1_has_heart_stored = False
p2_has_heart_stored = False
p1_name = ""
p2_name = ""

p1_walls, p2_walls = set(), set()
p1_crates, p2_crates = {}, {}
p1_portal, p2_portal = None, None
p1_thrones, p2_thrones = {}, {}      
p1_discovered_walls, p2_discovered_walls = set(), set()
p1_discovered_thrones, p2_discovered_thrones = set(), set()

temp_revealed_kings = set() 
p1_wardens_to_respawn, p2_wardens_to_respawn = [], []  
active_warden_respawn_idx = -1

pending_capture = None
sacrifice_player = -1
post_crack_state = None
post_crack_popup = None
turn_snapshot = {}
space_memory_enabled = False
p1_visited_spaces, p2_visited_spaces = set(), set()
active_popup = None

# Colors
BG_COLOR = (28, 28, 30)
GRID_COLOR = (63, 63, 66)
BTN_COLOR = (72, 72, 74)
CLOSE_COLOR = (255, 69, 58)
CONFIRM_COLOR = (52, 199, 89)
DISABLED_COLOR = (100, 100, 100)
PORTAL_GLOW = (160, 32, 240)

dim_overlay = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
dim_overlay.fill((0, 0, 0, 180))

portal_frame_index = 0
last_portal_update = 0
PORTAL_FRAME_TIME_MS = 100
thronecrack_frame_index = 0
thronecrack_last_update = 0
THRONECRACK_FRAME_TIME_MS = 33 
crate_anim_frame_index = 0
crate_anim_last_update = 0

p1_chars = [
    {"id": 0, "name": "King", "grid_x": -1, "grid_y": -1, "pixel_x": 0.0, "pixel_y": 0.0, "color": (0, 122, 255), "sprites": {}, "sacrificed": False},
    {"id": 1, "name": "Warden 1", "grid_x": -1, "grid_y": -1, "pixel_x": 0.0, "pixel_y": 0.0, "color": (142, 68, 173), "sprites": {}, "sacrificed": False},
    {"id": 2, "name": "Warden 2", "grid_x": -1, "grid_y": -1, "pixel_x": 0.0, "pixel_y": 0.0, "color": (142, 68, 173), "sprites": {}, "sacrificed": False}
]

p2_chars = [
    {"id": 0, "name": "King", "grid_x": -1, "grid_y": -1, "pixel_x": 0.0, "pixel_y": 0.0, "color": (255, 50, 50), "sprites": {}, "sacrificed": False},
    {"id": 1, "name": "Warden 1", "grid_x": -1, "grid_y": -1, "pixel_x": 0.0, "pixel_y": 0.0, "color": (200, 0, 0), "sprites": {}, "sacrificed": False},
    {"id": 2, "name": "Warden 2", "grid_x": -1, "grid_y": -1, "pixel_x": 0.0, "pixel_y": 0.0, "color": (200, 0, 0), "sprites": {}, "sacrificed": False}
]

load_all_sprites()

selected_char_idx = 0
captured_char_idx = -1
capturing_warden_pos = None

# --- Custom UI Drawers ---
def get_button_type(text, opt_type):
    if opt_type: return opt_type
    tl = text.lower()
    if tl in ["yes", "no", "cancel", "open", "leave closed", "back"]: return "button_small.png"
    if tl in ["end game", "close game", "delete save", "ouch"]: return "button_danger.png"
    if "settings" in tl or tl in ["pass screen timer", "music", "sound effects", "save / load"]: return "button_settings.png"
    if tl in ["start over", "play again", "load game", "save game", "play", "redeploy", "let's build!", "awesome", "got it", "fight!", "sacrifice", "acknowledge", "confirm p1 name", "start setup phase", "confirm portal placement", "lock setup"]: return "button_important.png"
    return "button_standard.png"

def draw_button(surface, rect, text, font, text_color=(255, 255, 255), disabled=False, override_type=None):
    b_name = get_button_type(text, override_type)
    img = ui_assets.get(b_name)
    
    if img:
        scaled = pygame.transform.smoothscale(img, (rect.width, rect.height))
    else:
        scaled = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        color = (72, 72, 74)
        if b_name == "button_danger.png": color = (255, 69, 58)
        elif b_name == "button_important.png": color = (52, 199, 89)
        elif b_name == "button_settings.png": color = (100, 100, 150)
        pygame.draw.rect(scaled, color, scaled.get_rect(), border_radius=12)

    if disabled:
        scaled.set_alpha(128)
        text_color = (150, 150, 150)
        
    surface.blit(scaled, rect)
    
    lbl = font.render(text, True, text_color)
    if disabled: lbl.set_alpha(128)
    surface.blit(lbl, lbl.get_rect(center=rect.center))

def draw_panel(surface, rect, alpha=230):
    bg = ui_assets.get("panel_background.png")
    if bg:
        scaled_bg = pygame.transform.smoothscale(bg, (rect.width, rect.height))
        scaled_bg.set_alpha(alpha)
        surface.blit(scaled_bg, rect)
    else:
        s = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        s.fill((44, 44, 46, alpha))
        surface.blit(s, rect)

def draw_action_medallion(surface, x, y, size, count):
    rect = pygame.Rect(0, 0, size, size)
    rect.center = (x, y)
    
    med_surf = pygame.Surface((size, size), pygame.SRCALPHA)
    bg = ui_assets.get("panel_background.png")
    if bg:
        scaled_bg = pygame.transform.smoothscale(bg, (size, size))
        med_surf.blit(scaled_bg, (0,0))
        dark = pygame.Surface((size, size), pygame.SRCALPHA)
        dark.fill((0, 0, 0, 150))
        med_surf.blit(dark, (0,0))
    else:
        med_surf.fill((40, 40, 40, 200))
        
    mask_surf = pygame.Surface((size, size), pygame.SRCALPHA)
    pygame.draw.circle(mask_surf, (255, 255, 255, 255), (size//2, size//2), size//2)
    med_surf.blit(mask_surf, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    
    surface.blit(med_surf, rect.topleft)
    
    lbl = font_large.render(str(count), True, (255, 215, 0))
    surface.blit(lbl, lbl.get_rect(center=(x, y)))

def draw_pulsing_sprite(surface, sprite, rect):
    surface.blit(sprite, rect)
    t = pygame.time.get_ticks()
    pulse_val = (math.sin(t * math.pi / 875.0) + 1.0) / 2.0
    alpha = int(pulse_val * 75)
    
    if alpha > 0:
        mask = pygame.mask.from_surface(sprite)
        mask_surf = mask.to_surface(setcolor=(255, 255, 255, alpha), unsetcolor=(0, 0, 0, 0))
        surface.blit(mask_surf, rect.topleft)

# --- Save & Load Implementation ---
def save_game_state(slot):
    state = {
        "p1_name": p1_name, "p2_name": p2_name,
        "p1_lives": p1_lives, "p2_lives": p2_lives,
        "p1_has_heart_stored": p1_has_heart_stored, "p2_has_heart_stored": p2_has_heart_stored,
        "actions_left": actions_left, "current_turn": current_turn,
        "game_state": game_state,
        "sacrifice_player": sacrifice_player,
        "active_warden_respawn_idx": active_warden_respawn_idx,
        "space_memory_enabled": space_memory_enabled,
        "final_winner": final_winner,
        "p1_setup_state": p1_setup_state,
        "p2_setup_state": p2_setup_state,
        "p1_portal": p1_portal, "p2_portal": p2_portal,
        "p1_thrones": {f"{k[0]},{k[1]}": v for k, v in p1_thrones.items()},
        "p2_thrones": {f"{k[0]},{k[1]}": v for k, v in p2_thrones.items()},
        "p1_crates": {f"{k[0]},{k[1]}": v for k, v in p1_crates.items()},
        "p2_crates": {f"{k[0]},{k[1]}": v for k, v in p2_crates.items()},
        "p1_walls": list(p1_walls), "p2_walls": list(p2_walls),
        "p1_discovered_walls": list(p1_discovered_walls), "p2_discovered_walls": list(p2_discovered_walls),
        "p1_discovered_thrones": list(p1_discovered_thrones), "p2_discovered_thrones": list(p2_discovered_thrones),
        "p1_visited_spaces": list(p1_visited_spaces), "p2_visited_spaces": list(p2_visited_spaces),
        "temp_revealed_kings": list(temp_revealed_kings),
        "p1_wardens_to_respawn": p1_wardens_to_respawn, "p2_wardens_to_respawn": p2_wardens_to_respawn,
        "p1_chars": [{k: v for k, v in c.items() if k not in ["sprites", "color"]} for c in p1_chars],
        "p2_chars": [{k: v for k, v in c.items() if k not in ["sprites", "color"]} for c in p2_chars],
        "pending_capture": pending_capture
    }
    try:
        with open(f"id_save_{slot}.json", "w") as f:
            json.dump(state, f)
        return True
    except Exception as e:
        print("Save Error:", e)
        return False

def load_game_state(slot):
    global p1_name, p2_name, p1_lives, p2_lives, p1_has_heart_stored, p2_has_heart_stored
    global actions_left, current_turn, game_state, sacrifice_player, active_warden_respawn_idx
    global space_memory_enabled, final_winner, p1_portal, p2_portal, pending_capture
    global p1_setup_state, p2_setup_state
    global p1_thrones, p2_thrones, p1_crates, p2_crates
    global p1_walls, p2_walls, p1_discovered_walls, p2_discovered_walls
    global p1_discovered_thrones, p2_discovered_thrones, p1_visited_spaces, p2_visited_spaces
    global temp_revealed_kings, p1_wardens_to_respawn, p2_wardens_to_respawn
    
    try:
        if not os.path.exists(f"id_save_{slot}.json"):
            return False
        with open(f"id_save_{slot}.json", "r") as f:
            state = json.load(f)
            
        p1_name = state.get("p1_name", p1_name)
        p2_name = state.get("p2_name", p2_name)
        p1_lives = state.get("p1_lives", 3)
        p2_lives = state.get("p2_lives", 3)
        p1_has_heart_stored = state.get("p1_has_heart_stored", False)
        p2_has_heart_stored = state.get("p2_has_heart_stored", False)
        actions_left = state.get("actions_left", 6)
        current_turn = state.get("current_turn", 1)
        game_state = state.get("game_state", "PLAY")
        sacrifice_player = state.get("sacrifice_player", -1)
        active_warden_respawn_idx = state.get("active_warden_respawn_idx", -1)
        space_memory_enabled = state.get("space_memory_enabled", False)
        final_winner = state.get("final_winner", None)
        p1_setup_state = state.get("p1_setup_state", "random")
        p2_setup_state = state.get("p2_setup_state", "random")
        p1_portal = tuple(state["p1_portal"]) if state.get("p1_portal") is not None else None
        p2_portal = tuple(state["p2_portal"]) if state.get("p2_portal") is not None else None
        pending_capture = state.get("pending_capture", None)
        
        p1_thrones.clear(); p1_thrones.update({tuple(map(int, k.split(','))): v for k, v in state.get("p1_thrones", {}).items()})
        p2_thrones.clear(); p2_thrones.update({tuple(map(int, k.split(','))): v for k, v in state.get("p2_thrones", {}).items()})
        p1_crates.clear(); p1_crates.update({tuple(map(int, k.split(','))): v for k, v in state.get("p1_crates", {}).items()})
        p2_crates.clear(); p2_crates.update({tuple(map(int, k.split(','))): v for k, v in state.get("p2_crates", {}).items()})
        
        p1_walls.clear(); p1_walls.update([tuple(x) for x in state.get("p1_walls", [])])
        p2_walls.clear(); p2_walls.update([tuple(x) for x in state.get("p2_walls", [])])
        p1_discovered_walls.clear(); p1_discovered_walls.update([tuple(x) for x in state.get("p1_discovered_walls", [])])
        p2_discovered_walls.clear(); p2_discovered_walls.update([tuple(x) for x in state.get("p2_discovered_walls", [])])
        p1_discovered_thrones.clear(); p1_discovered_thrones.update([tuple(x) for x in state.get("p1_discovered_thrones", [])])
        p2_discovered_thrones.clear(); p2_discovered_thrones.update([tuple(x) for x in state.get("p2_discovered_thrones", [])])
        p1_visited_spaces.clear(); p1_visited_spaces.update([tuple(x) for x in state.get("p1_visited_spaces", [])])
        p2_visited_spaces.clear(); p2_visited_spaces.update([tuple(x) for x in state.get("p2_visited_spaces", [])])
        temp_revealed_kings.clear(); temp_revealed_kings.update([tuple(x) for x in state.get("temp_revealed_kings", [])])
        
        p1_wardens_to_respawn.clear(); p1_wardens_to_respawn.extend(state.get("p1_wardens_to_respawn", []))
        p2_wardens_to_respawn.clear(); p2_wardens_to_respawn.extend(state.get("p2_wardens_to_respawn", []))
        
        for i, c_data in enumerate(state.get("p1_chars", [])):
            for k, v in c_data.items(): p1_chars[i][k] = v
        for i, c_data in enumerate(state.get("p2_chars", [])):
            for k, v in c_data.items(): p2_chars[i][k] = v
        
        return True
    except Exception as e:
        print("Load Error:", e)
        return False

def handle_crate_open(crate_pos, player_id):
    global p1_has_heart_stored, p2_has_heart_stored, active_popup, game_state
    global crate_anim_frame_index, crate_anim_last_update
    enemy_crates = p2_crates if player_id == 1 else p1_crates
    
    crate_type = enemy_crates.pop(crate_pos, None)
    if not crate_type: return
    
    crate_anim_frame_index = 0
    crate_anim_last_update = pygame.time.get_ticks()

    if crate_type == "Heart":
        has_heart = p1_has_heart_stored if player_id == 1 else p2_has_heart_stored
        if has_heart:
            active_popup = {
                "type": "CRATE_RESULT",
                "title": "HEART CRATE",
                "lines": ["You found a Heart Crate!", "But you already have one stored.", "The crate was discarded."],
                "btn_text": "Okay",
                "crate_type": "Heart"
            }
        else:
            if player_id == 1: p1_has_heart_stored = True
            else: p2_has_heart_stored = True
            active_popup = {
                "type": "CRATE_RESULT",
                "title": "HEART CRATE",
                "lines": ["You found a Heart Crate!", "You safely stored 1 Heart Crate.", "(It will prompt you when needed)"],
                "btn_text": "Awesome",
                "crate_type": "Heart"
            }
            
    elif crate_type == "Skull":
        active_popup = {
            "type": "CRATE_RESULT",
            "title": "SKULL CRATE!",
            "lines": ["Skull Crate!", "Your King has been sent back."],
            "btn_text": "Acknowledge",
            "crate_type": "Skull"
        }

def resolve_encounter(char, dest_c, dest_r, active_player, warden_hit, hit_warden_idx, throne_conquered, used_heart=False):
    global game_state, sacrifice_player, p1_lives, p2_lives, captured_char_idx
    global capturing_warden_pos, pending_capture, active_popup, final_winner
    global post_crack_state, post_crack_popup, p1_wardens_to_respawn, p2_wardens_to_respawn
    global next_state_after_pass

    curr = (dest_c, dest_r)
    enemy_chars = p2_chars if active_player == 1 else p1_chars

    if throne_conquered:
        game_state = "THRONE_CRACK"
        sacrifice_player = 2 if active_player == 1 else 1
        loser_name = p2_name if active_player == 1 else p1_name
        winner_name = p1_name if active_player == 1 else p2_name

        if active_player == 1: p2_lives -= 1
        else: p1_lives -= 1

        target_lives = p2_lives if active_player == 1 else p1_lives
        if target_lives <= 0:
            final_winner = active_player
            post_crack_state = "WIN_P1" if active_player == 1 else "WIN_P2"
            post_crack_popup = None
        else:
            post_crack_state = "PASS_TURN"
            next_state_after_pass = "CHOOSE_WARDEN_LOSS"
            post_crack_popup = {
                "title": "THRONE TAKEN!",
                "lines": [f"{winner_name} discovered a Throne!", f"{loser_name} has lost 1 Life.", f"Pass phone to {loser_name} to sacrifice a Warden."],
                "btn_text": "Sacrifice"
            }

        if warden_hit and post_crack_state not in ["WIN_P1", "WIN_P2"]:
            capturing_warden_pos = (enemy_chars[hit_warden_idx]["grid_x"], enemy_chars[hit_warden_idx]["grid_y"])
            
            if used_heart:
                if active_player == 1: p2_wardens_to_respawn.append(hit_warden_idx)
                else: p1_wardens_to_respawn.append(hit_warden_idx)
                enemy_chars[hit_warden_idx]["grid_x"] = -1
                enemy_chars[hit_warden_idx]["grid_y"] = -1
                pending_capture = None
            else:
                captured_char_idx = p1_chars.index(char) if active_player == 1 else p2_chars.index(char)
                pending_capture = {
                    "captured_char_idx": captured_char_idx,
                    "capturing_warden_pos": capturing_warden_pos,
                    "warden_owner": 2 if active_player == 1 else 1,
                    "warden_idx": hit_warden_idx
                }

    elif warden_hit:
        capturing_warden_pos = (enemy_chars[hit_warden_idx]["grid_x"], enemy_chars[hit_warden_idx]["grid_y"])

        if active_player == 1: p2_wardens_to_respawn.append(hit_warden_idx)
        else: p1_wardens_to_respawn.append(hit_warden_idx)

        enemy_chars[hit_warden_idx]["grid_x"] = -1
        enemy_chars[hit_warden_idx]["grid_y"] = -1

        if used_heart:
            active_popup = {
                "type": "INFO",
                "title": "HEART USED!", 
                "lines": ["You consumed your Heart Crate!", "You avoided capture.", "The enemy Warden was defeated!"], 
                "btn_text": "Continue"
            }
        else:
            captured_char_idx = p1_chars.index(char) if active_player == 1 else p2_chars.index(char)
            game_state = "PASS_TURN"
            next_state_after_pass = "RESPAWN_CHOICE"
            active_popup = {"type": "INFO", "title": "CAPTURED!", "lines": ["An enemy Warden caught you!", "Choose an empty friendly throne", "to respawn your piece."], "btn_text": "Got It"}

    elif not throne_conquered and not warden_hit:
        enemy_crates = p2_crates if active_player == 1 else p1_crates
        if curr in enemy_crates:
            active_popup = {
                "type": "CRATE_INTERACTION",
                "title": "ENEMY CRATE FOUND",
                "lines": ["Would you like to open this crate?"],
                "crate_pos": curr
            }

def execute_move(char, dest_c, dest_r, active_player):
    global active_popup

    char["grid_x"], char["grid_y"] = dest_c, dest_r
    char["pixel_x"], char["pixel_y"] = get_cell_center(dest_c, dest_r)

    curr = (dest_c, dest_r)
    enemy_thrones = p2_thrones if active_player == 1 else p1_thrones
    discovered_thrones = p1_discovered_thrones if active_player == 1 else p2_discovered_thrones
    enemy_chars = p2_chars if active_player == 1 else p1_chars

    throne_conquered = False
    if curr in enemy_thrones and curr not in discovered_thrones:
        discovered_thrones.add(curr)
        del enemy_thrones[curr]
        throne_conquered = True

    warden_hit = False
    hit_warden_idx = -1
    for ec_idx, ec in enumerate(enemy_chars):
        if not ec["sacrificed"] and "Warden" in ec["name"] and ec["grid_x"] == dest_c and ec["grid_y"] == dest_r:
            warden_hit = True
            hit_warden_idx = ec_idx
            break
            
    has_heart = p1_has_heart_stored if active_player == 1 else p2_has_heart_stored

    if warden_hit and has_heart:
        active_popup = {
            "type": "HEART_PROMPT",
            "title": "WARDEN ENCOUNTER!",
            "lines": ["An enemy Warden is here!", "Use your stored Heart Crate", "to avoid capture?"],
            "char": char,
            "dest_c": dest_c,
            "dest_r": dest_r,
            "hit_warden_idx": hit_warden_idx,
            "throne_conquered": throne_conquered,
            "active_player": active_player
        }
    else:
        resolve_encounter(char, dest_c, dest_r, active_player, warden_hit, hit_warden_idx, throne_conquered)


# --- Shared Utilities ---
def draw_logo(surface):
    if logo_sprite:
        logo_sprite.set_alpha(255)
        rect = logo_sprite.get_rect(center=(screen_width // 2, int(screen_height * 0.08)))
        surface.blit(logo_sprite, rect)
    else:
        title_text = font_large.render("Inverse Dimensions", True, (255, 215, 0))
        surface.blit(title_text, title_text.get_rect(center=(screen_width // 2, int(screen_height * 0.08))))

def get_throne_choice_rects():
    m_h = int(screen_height * 0.6)
    m_rect = pygame.Rect(screen_width // 2 - modal_width // 2, screen_height // 2 - m_h // 2, modal_width, m_h)
    opts = ["Empty", "King", "Warden 1", "Warden 2"]
    opt_h = m_h // 5
    start_y = m_rect.top + int(opt_h * 0.8)
    rects = []
    for i in range(4):
        r = pygame.Rect(m_rect.left + 20, start_y + i * opt_h, m_rect.width - 40, opt_h - 10)
        rects.append((opts[i], r))
    return m_rect, rects

def get_dynamic_menu_rects(opts):
    m_h = int(screen_height * 0.8)
    if platform_mode == "desktop": m_h = int(screen_height * 0.9)
    m_rect = pygame.Rect(screen_width // 2 - modal_width // 2, screen_height // 2 - m_h // 2, modal_width, m_h)
    opt_h = min(m_h // max(5, len(opts) + 1), int(screen_height * 0.12))
    total_opts_h = len(opts) * opt_h
    start_y = m_rect.top + (m_h - total_opts_h) // 2 + 20
    rects = []
    for i in range(len(opts)):
        r = pygame.Rect(m_rect.left + 20, start_y + i * opt_h, m_rect.width - 40, opt_h - 10)
        rects.append((opts[i], r))
    return m_rect, rects

def get_crate_choice_rects():
    m_h = int(screen_height * 0.4)
    m_rect = pygame.Rect(screen_width // 2 - modal_width // 2, screen_height // 2 - m_h // 2, modal_width, m_h)
    padding = 20
    btn_w = (modal_width - (padding * 3)) // 2
    btn_h = m_h - int(m_h * 0.3) - padding
    h_rect = pygame.Rect(m_rect.left + padding, m_rect.top + int(m_h * 0.3), btn_w, btn_h)
    s_rect = pygame.Rect(m_rect.left + padding * 2 + btn_w, m_rect.top + int(m_h * 0.3), btn_w, btn_h)
    return m_rect, h_rect, s_rect

def get_confirm_restart_rects():
    y_r = pygame.Rect(modal_rect.centerx - int(confirm_btn_width * 0.45), modal_rect.bottom - int(confirm_btn_height * 1.5), int(confirm_btn_width * 0.4), confirm_btn_height)
    n_r = pygame.Rect(modal_rect.centerx + int(confirm_btn_width * 0.05), modal_rect.bottom - int(confirm_btn_height * 1.5), int(confirm_btn_width * 0.4), confirm_btn_height)
    return y_r, n_r

def create_turn_snapshot():
    global turn_snapshot
    turn_snapshot = {
        "p1_lives": p1_lives, "p2_lives": p2_lives,
        "p1_has_heart_stored": p1_has_heart_stored, "p2_has_heart_stored": p2_has_heart_stored,
        "actions_left": actions_left, "current_turn": current_turn,
        "p1_thrones": p1_thrones.copy(), "p2_thrones": p2_thrones.copy(),
        "p1_crates": p1_crates.copy(), "p2_crates": p2_crates.copy(),
        "p1_walls": p1_walls.copy(), "p2_walls": p2_walls.copy(),
        "p1_discovered_walls": p1_discovered_walls.copy(), "p2_discovered_walls": p2_discovered_walls.copy(),
        "p1_discovered_thrones": p1_discovered_thrones.copy(), "p2_discovered_thrones": p2_discovered_thrones.copy(),
        "p1_visited_spaces": p1_visited_spaces.copy(), "p2_visited_spaces": p2_visited_spaces.copy(),
        "p1_wardens_to_respawn": p1_wardens_to_respawn.copy(), "p2_wardens_to_respawn": p2_wardens_to_respawn.copy(),
        "p1_chars": [{k: v for k, v in c.items() if k not in ["sprites", "color"]} for c in p1_chars],
        "p2_chars": [{k: v for k, v in c.items() if k not in ["sprites", "color"]} for c in p2_chars],
        "game_state": game_state,
        "temp_revealed_kings": temp_revealed_kings.copy(),
        "pending_capture": pending_capture.copy() if pending_capture else None,
        "sacrifice_player": sacrifice_player,
        "active_warden_respawn_idx": active_warden_respawn_idx,
    }

def restore_turn_snapshot():
    global p1_lives, p2_lives, actions_left, current_turn, p1_has_heart_stored, p2_has_heart_stored
    global p1_thrones, p2_thrones, p1_crates, p2_crates, p1_walls, p2_walls, p1_discovered_walls, p2_discovered_walls
    global p1_discovered_thrones, p2_discovered_thrones, p1_visited_spaces, p2_visited_spaces
    global p1_wardens_to_respawn, p2_wardens_to_respawn, game_state, temp_revealed_kings
    global pending_capture, sacrifice_player, active_warden_respawn_idx
    if not turn_snapshot: return

    p1_lives, p2_lives = turn_snapshot["p1_lives"], turn_snapshot["p2_lives"]
    p1_has_heart_stored, p2_has_heart_stored = turn_snapshot["p1_has_heart_stored"], turn_snapshot["p2_has_heart_stored"]
    actions_left, current_turn = turn_snapshot["actions_left"], turn_snapshot["current_turn"]
    p1_thrones.clear(); p1_thrones.update(turn_snapshot["p1_thrones"])
    p2_thrones.clear(); p2_thrones.update(turn_snapshot["p2_thrones"])
    p1_crates.clear(); p1_crates.update(turn_snapshot["p1_crates"])
    p2_crates.clear(); p2_crates.update(turn_snapshot["p2_crates"])
    p1_walls.clear(); p1_walls.update(turn_snapshot["p1_walls"])
    p2_walls.clear(); p2_walls.update(turn_snapshot["p2_walls"])
    p1_discovered_walls.clear(); p1_discovered_walls.update(turn_snapshot["p1_discovered_walls"])
    p2_discovered_walls.clear(); p2_discovered_walls.update(turn_snapshot["p2_discovered_walls"])
    p1_discovered_thrones.clear(); p1_discovered_thrones.update(turn_snapshot["p1_discovered_thrones"])
    p2_discovered_thrones.clear(); p2_discovered_thrones.update(turn_snapshot["p1_discovered_thrones"])
    p1_visited_spaces.clear(); p1_visited_spaces.update(turn_snapshot["p1_visited_spaces"])
    p2_visited_spaces.clear(); p2_visited_spaces.update(turn_snapshot["p2_visited_spaces"])
    p1_wardens_to_respawn.clear(); p1_wardens_to_respawn.extend(turn_snapshot["p1_wardens_to_respawn"])
    p2_wardens_to_respawn.clear(); p2_wardens_to_respawn.extend(turn_snapshot["p2_wardens_to_respawn"])

    for i, c_data in enumerate(turn_snapshot["p1_chars"]):
        for k, v in c_data.items(): p1_chars[i][k] = v
    for i, c_data in enumerate(turn_snapshot["p2_chars"]):
        for k, v in c_data.items(): p2_chars[i][k] = v

    game_state = turn_snapshot["game_state"]
    temp_revealed_kings.clear(); temp_revealed_kings.update(turn_snapshot["temp_revealed_kings"])
    pending_capture = turn_snapshot["pending_capture"].copy() if turn_snapshot["pending_capture"] else None
    sacrifice_player = turn_snapshot["sacrifice_player"]
    active_warden_respawn_idx = turn_snapshot["active_warden_respawn_idx"]

def mark_space_visited(p_id, cell):
    if not space_memory_enabled: return
    c, r = cell
    if p_id == 1 and r > 5: p1_visited_spaces.add(cell)
    elif p_id == 2 and r < 5: p2_visited_spaces.add(cell)

def get_bfs_path(start, target, player, char_name):
    queue = [[start]]
    visited = {start}
    while queue:
        path = queue.pop(0)
        curr = path[-1]
        if curr == target:
            return path[1:]
        
        c, r = curr
        for dc, dr in [(0,1), (0,-1), (1,0), (-1,0)]:
            nc, nr = c+dc, r+dr
            if 0 <= nc < COLS and 0 <= nr < ROWS:
                if "Warden" in char_name:
                    if player == 1 and nr > 4: continue
                    if player == 2 and nr < 6: continue
                if (nc, nr) not in visited:
                    friendly_walls = p1_walls if player == 1 else p2_walls
                    friendly_chars = p1_chars if player == 1 else p2_chars
                    enemy_walls = p2_walls if player == 1 else p1_walls
                    disc_walls = p1_discovered_walls if player == 1 else p2_discovered_walls
                    
                    if (nc, nr) in friendly_walls: continue
                    if (nc, nr) in enemy_walls and (nc, nr) in disc_walls: continue
                    
                    blocked_by_char = False
                    for f_char in friendly_chars:
                        if not f_char["sacrificed"] and f_char["grid_x"] == nc and f_char["grid_y"] == nr:
                            blocked_by_char = True
                            break
                    if blocked_by_char: continue
                    
                    visited.add((nc, nr))
                    queue.append(path + [(nc, nr)])
    return []

def check_valid_move(new_x, new_y, active_player, moving_char_name):
    if new_x < 0 or new_x >= COLS or new_y < 0 or new_y >= ROWS: return "OUT"
    if "Warden" in moving_char_name:
        if active_player == 1 and new_y > 4: return "OUT"
        if active_player == 2 and new_y < 6: return "OUT"
    friendly_walls = p1_walls if active_player == 1 else p2_walls
    enemy_walls = p2_walls if active_player == 1 else p1_walls
    friendly_chars = p1_chars if active_player == 1 else p2_chars
    enemy_chars = p2_chars if active_player == 1 else p1_chars

    if (new_x, new_y) in friendly_walls: return "WALL"
    if (new_x, new_y) in enemy_walls:
        discovered = p1_discovered_walls if active_player == 1 else p2_discovered_walls
        if (new_x, new_y) in discovered:
            return "DISCOVERED_WALL"
        return "ENEMY_WALL"
    
    for c in friendly_chars:
        if not c["sacrificed"] and c["grid_x"] == new_x and c["grid_y"] == new_y: return "COLLISION"
    for ec in enemy_chars:
        if not ec["sacrificed"] and "King" in ec["name"] and ec["grid_x"] == new_x and ec["grid_y"] == new_y:
            temp_revealed_kings.add((new_x, new_y))
            return "KING_COLLISION"
    return "OK"

def reset_game():
    global game_state, current_turn, actions_left, p1_portal, p2_portal, selected_char_idx, p1_lives, p2_lives
    global p1_wardens_to_respawn, p2_wardens_to_respawn, temp_revealed_kings, pending_capture, sacrifice_player, active_popup, next_state_after_pass
    global p1_name, p2_name, space_memory_enabled, p1_visited_spaces, p2_visited_spaces, final_winner
    global p1_has_heart_stored, p2_has_heart_stored, post_crack_state, post_crack_popup, thronecrack_frame_index, turn_snapshot, rules_page_index
    global p1_setup_state, p2_setup_state
    
    pygame.key.stop_text_input()
    pygame.key.start_text_input()
    game_state = "ENTER_NAME_P1"
    p1_name, p2_name = "", ""
    next_state_after_pass = None
    current_turn = 1
    p1_lives, p2_lives = 3, 3
    p1_has_heart_stored, p2_has_heart_stored = False, False
    actions_left = 6
    selected_char_idx = 0
    p1_walls.clear(); p2_walls.clear()
    p1_thrones.clear(); p2_thrones.clear()
    p1_crates.clear(); p2_crates.clear()
    p1_discovered_walls.clear(); p2_discovered_walls.clear()
    p1_discovered_thrones.clear(); p2_discovered_thrones.clear()
    p1_wardens_to_respawn.clear(); p2_wardens_to_respawn.clear()
    p1_visited_spaces.clear(); p2_visited_spaces.clear()
    temp_revealed_kings.clear()
    p1_portal, p2_portal = None, None
    pending_capture = None
    sacrifice_player = -1
    active_popup, post_crack_state, post_crack_popup = None, None, None
    thronecrack_frame_index = 0
    space_memory_enabled = False
    rules_page_index = 0
    final_winner = None
    turn_snapshot.clear()
    p1_setup_state = "random"
    p2_setup_state = "random"
    for char in p1_chars + p2_chars: char["sacrificed"] = False

def draw_hearts(surface, x, y, lives_count):
    spacing = int(cell_size * 0.8)
    total_slots = max(3, lives_count) 
    for i in range(total_slots): 
        pos_x = x + (i * spacing)
        if i < lives_count:
            if life_sprite: surface.blit(life_sprite, life_sprite.get_rect(center=(pos_x, y)))
            else: pygame.draw.circle(surface, (231, 76, 60), (pos_x, y), 10)
        else:
            if unlife_sprite: surface.blit(unlife_sprite, unlife_sprite.get_rect(center=(pos_x, y)))
            else: pygame.draw.circle(surface, (127, 140, 141), (pos_x, y), 10)

def get_current_setup_task(player_id, p_name):
    p_walls, p_thrones, p_crates = (p1_walls, p1_thrones, p1_crates) if player_id == 1 else (p2_walls, p2_thrones, p2_crates)
    if "King" not in p_thrones.values(): return f"{p_name}: Place King"
    if "Warden 1" not in p_thrones.values(): return f"{p_name}: Place Warden 1"
    if "Warden 2" not in p_thrones.values(): return f"{p_name}: Place Warden 2"
    if "Heart" not in p_crates.values(): return f"{p_name}: Place Heart Crate"
    if "Skull" not in p_crates.values(): return f"{p_name}: Place Skull Crate"
    if len(p_walls) < 10: return f"{p_name}: Place Walls ({len(p_walls)}/10)"
    return f"{p_name}: Setup Complete! Lock Setup."

def handle_setup_clicks(pos, active_player, walls_set, thrones_dict, crates_dict, start_row, end_row):
    global setup_mode, active_popup
    portal_cell = p2_portal if active_player == 1 else p1_portal
    c, r = get_grid_from_screen(pos[0], pos[1])
    if start_row <= r < end_row and 0 <= c < COLS:
        if setup_mode == "wall":
            if (c, r) not in thrones_dict and (c, r) not in crates_dict and portal_cell != (c, r):
                if (c, r) in walls_set: walls_set.remove((c, r))
                elif len(walls_set) < 10: walls_set.add((c, r))
        elif setup_mode == "throne":
            if (c, r) not in walls_set and (c, r) not in crates_dict and portal_cell != (c, r):
                active_popup = {"type": "THRONE_CHOICE", "cell": (c, r), "player": active_player}
        elif setup_mode == "crate":
            if (c, r) not in walls_set and (c, r) not in thrones_dict and portal_cell != (c, r):
                active_popup = {"type": "CRATE_CHOICE", "cell": (c, r), "player": active_player}

def randomize_player_board(active_player, walls_set, thrones_dict, crates_dict, start_row, end_row, mode="fill"):
    if mode == "clear":
        walls_set.clear()
        thrones_dict.clear()
        crates_dict.clear()
        return

    portal_cell = p2_portal if active_player == 1 else p1_portal
    occupied = set(walls_set) | set(thrones_dict.keys()) | set(crates_dict.keys())
    if portal_cell: occupied.add(portal_cell)
    
    available_cells = [(c, r) for r in range(start_row, end_row) for c in range(COLS) if (c, r) not in occupied]
    random.shuffle(available_cells)
    
    existing_thrones = list(thrones_dict.values())
    for thr in ["King", "Warden 1", "Warden 2"]: 
        if thr not in existing_thrones and available_cells: thrones_dict[available_cells.pop()] = thr
        
    existing_crates = list(crates_dict.values())
    for crt in ["Heart", "Skull"]: 
        if crt not in existing_crates and available_cells: crates_dict[available_cells.pop()] = crt
        
    needed_walls = 10 - len(walls_set)
    for _ in range(needed_walls): 
        if available_cells: walls_set.add(available_cells.pop())

def init_player_positions(thrones_dict, chars_list):
    for cell, occupant in thrones_dict.items():
        idx = 0 if occupant == "King" else 1 if occupant == "Warden 1" else 2 if occupant == "Warden 2" else -1
        if idx != -1:
            chars_list[idx]["grid_x"], chars_list[idx]["grid_y"] = cell
            chars_list[idx]["pixel_x"], chars_list[idx]["pixel_y"] = get_cell_center(*cell)

def trigger_pass_transition():
    global game_state, next_state_after_pass, current_turn, p1_lives, p2_lives, actions_left
    global selected_char_idx, active_warden_respawn_idx, active_popup
    play_start_click()
    if next_state_after_pass:
        game_state = next_state_after_pass
        next_state_after_pass = None
        if game_state == "SETUP_PORTAL_P2":
            active_popup = {"title": f"{p2_name.upper()} SETUP!", "lines": [f"Place your Portal on {p1_name}'s side.", "That's the top half of the board!", "Tap a cell, then confirm."], "btn_text": "Next Phase"}
        elif game_state == "SETUP_P1":
            active_popup = {"title": f"{p1_name.upper()} LAYOUT SETUP", "lines": ["Tap 'Wall', 'Throne', or 'Crate'.", "Consult the status text instruction.", "Or click 'Random' to auto-fill!"], "btn_text": "Let's Build!"}
        elif game_state == "SETUP_P2":
            active_popup = {"title": f"{p2_name.upper()} LAYOUT SETUP", "lines": ["Tap 'Wall', 'Throne', or 'Crate'.", "Consult the status text instruction.", "Or click 'Random' to auto-fill!"], "btn_text": "Let's Build!"}
        elif game_state == "PLAY":
            active_popup = {"title": "GAME START!", "lines": [f"{p1_name} starts with 6 Actions.", f"Seek out and land on {p2_name}'s Thrones.", "Move carefully. Wardens lie in wait!"], "btn_text": "Fight!"}
            create_turn_snapshot()
    else:
        active_warden_respawns = p1_wardens_to_respawn if current_turn == 1 else p2_wardens_to_respawn
        active_list = p1_chars if current_turn == 1 else p2_chars
        active_warden_respawns = [w for w in active_warden_respawns if not active_list[w]["sacrificed"]]
        if len(active_warden_respawns) > 0:
            game_state = "WARDEN_RESPAWN"
            active_warden_respawn_idx = active_warden_respawns[0]
            active_popup = {"title": "WARDEN DIED?", "lines": ["Your Warden caught a piece, but died in process.", "You must select an empty friendly throne", "to redeploy them back into battle."], "btn_text": "Redeploy"}
        else:
            game_state = "PLAY"
        
        actions_left = (p1_lives if current_turn == 1 else p2_lives) * 2
        selected_char_idx = 0
        temp_revealed_kings.clear()
        create_turn_snapshot()

def perform_portal_swap(char, player_id):
    if "Warden" in char["name"]: return
    curr_loc = (char["grid_x"], char["grid_y"])
    dest_portal = p2_portal if curr_loc == p1_portal else p1_portal
    mark_space_visited(player_id, dest_portal)
    play_walk_sound()
    execute_move(char, dest_portal[0], dest_portal[1], player_id)

intro_start_time = pygame.time.get_ticks()
# NOTE: 'running' and 'clock' are declared up top with the other globals
# (pygbag requires all globals declared at once before function defs).

async def _game_main():
    global actions_left, active_popup, active_warden_respawn_idx, capturing_warden_pos, crate_anim_frame_index, crate_anim_last_update, current_turn, final_winner, game_state, last_portal_update, movement_mode, music_on, next_state_after_pass, p1_has_heart_stored, p1_lives, p1_name, p1_portal, p1_setup_state, p2_has_heart_stored, p2_lives, p2_name, p2_portal, p2_setup_state, pass_screen_start_time, pass_screen_timer, pending_capture, platform_mode, portal_frame_index, post_crack_popup, post_crack_state, rules_from_home, rules_page_index, running, sacrifice_player, selected_char_idx, setup_mode, sfx_on, space_memory_enabled, thronecrack_frame_index, thronecrack_last_update
    while running:
        # Mobile-keyboard fix: tell the browser where the text field is
        # so tapping it opens the virtual keyboard (pygame-web quirk:
        # start_text_input() alone does not reliably open it on phones).
        if game_state == "ENTER_NAME_P1":
            try:
                pygame.key.set_text_input_rect(p1_input_rect)
            except Exception:
                pass
        elif game_state == "ENTER_NAME_P2":
            try:
                pygame.key.set_text_input_rect(p2_input_rect)
            except Exception:
                pass
        current_time = pygame.time.get_ticks()
    
        if portal_frames:
            if current_time - last_portal_update >= PORTAL_FRAME_TIME_MS:
                portal_frame_index = (portal_frame_index + 1) % len(portal_frames)
                last_portal_update = current_time

        # --- Event Handler ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.TEXTINPUT:
                if game_state == "ENTER_NAME_P1" and len(p1_name) < 16:
                    p1_name += event.text
                elif game_state == "ENTER_NAME_P2" and len(p2_name) < 16:
                    p2_name += event.text

            if event.type == pygame.KEYDOWN:
                if game_state in ["ENTER_NAME_P1", "ENTER_NAME_P2"]:
                    if event.key == pygame.K_BACKSPACE:
                        if game_state == "ENTER_NAME_P1": p1_name = p1_name[:-1]
                        else: p2_name = p2_name[:-1]
                    elif event.key in [pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_TAB]:
                        if game_state == "ENTER_NAME_P1":
                            if not p1_name.strip(): p1_name = "Player 1"
                            pygame.key.stop_text_input()
                            game_state = "PASS_TO_PLAYER_2"
                        elif game_state == "ENTER_NAME_P2":
                            if not p2_name.strip(): p2_name = "Player 2"
                            pygame.key.stop_text_input()
                            game_state = "SPACE_MEMORY_PROMPT"
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos

                if game_state == "INTRO":
                    play_start_click()
                    game_state = "HOME_MENU"
                    bg_surface.set_alpha(255)
                    if logo_sprite: logo_sprite.set_alpha(255)
                    continue
                
                if game_state == "HOME_MENU" and not active_popup:
                    if home_menu_rects["New Game"].collidepoint(pos):
                        play_start_click()
                        reset_game()
                        game_state = "ENTER_NAME_P1"
                    elif home_menu_rects["Load Game"].collidepoint(pos):
                        play_normal_click()
                        active_popup = {"type": "DYNAMIC_MENU", "title": "LOAD FROM SLOT", "opts": ["Load Slot 1", "Load Slot 2", "Load Slot 3", "Back"]}
                    elif home_menu_rects["Game Rules"].collidepoint(pos):
                        play_normal_click()
                        rules_page_index = 0
                        rules_from_home = True
                        game_state = "RULES_SCREEN"
                    elif home_menu_rects["Settings"].collidepoint(pos):
                        play_normal_click()
                        active_popup = {"type": "DYNAMIC_MENU", "title": "GAME SETTINGS", "opts": ["Platform Settings", "Movement Mode", "Pass Screen Timer", "Music", "Sound Effects", "Back"]}
                    elif home_menu_rects["Close Game"].collidepoint(pos):
                        play_normal_click()
                        running = False
                    continue

                if home_btn_rect.collidepoint(pos) and not active_popup and game_state != "THRONE_CRACK" and game_state != "HOME_MENU":
                    play_normal_click()
                    active_popup = {"type": "DYNAMIC_MENU", "title": "MAIN MENU", "opts": ["Resume Game", "Game Settings", "Player Settings", "Save / Load", "Start Over", "End Game", "Close Game"]}
                    continue 

                if active_popup:
                    popup_type = active_popup.get("type", "INFO")
                    if popup_type == "THRONE_CHOICE":
                        m_rect, opts_rects = get_throne_choice_rects()
                        for opt, r in opts_rects:
                            if r.collidepoint(pos):
                                play_normal_click()
                                p_id = active_popup["player"]
                                cell = active_popup["cell"]
                                t_dict = p1_thrones if p_id == 1 else p2_thrones
                                if opt == "Empty":
                                    if cell in t_dict: del t_dict[cell]
                                else:
                                    for k, v in list(t_dict.items()):
                                        if v == opt: del t_dict[k]
                                    t_dict[cell] = opt
                                active_popup = None
                                break
                            
                    elif popup_type == "CRATE_CHOICE":
                        m_rect, hc_rect, sc_rect = get_crate_choice_rects()
                        p_id, cell = active_popup["player"], active_popup["cell"]
                        crates_dict = p1_crates if p_id == 1 else p2_crates
                        if hc_rect.collidepoint(pos):
                            play_normal_click()
                            for k, v in list(crates_dict.items()):
                                if v == "Heart": del crates_dict[k]
                            crates_dict[cell] = "Heart"
                            active_popup = None
                        elif sc_rect.collidepoint(pos):
                            play_normal_click()
                            for k, v in list(crates_dict.items()):
                                if v == "Skull": del crates_dict[k]
                            crates_dict[cell] = "Skull"
                            active_popup = None
                        elif not m_rect.collidepoint(pos):
                            active_popup = None

                    elif popup_type == "HEART_PROMPT":
                        y_rect, n_rect = get_confirm_restart_rects()
                        if y_rect.collidepoint(pos):
                            play_start_click()
                            ap = active_popup["active_player"]
                            if ap == 1: p1_has_heart_stored = False
                            else: p2_has_heart_stored = False
                        
                            char = active_popup["char"]
                            dc = active_popup["dest_c"]
                            dr = active_popup["dest_r"]
                            hw_idx = active_popup["hit_warden_idx"]
                            tc = active_popup["throne_conquered"]
                        
                            active_popup = None
                            resolve_encounter(char, dc, dr, ap, True, hw_idx, tc, used_heart=True)
                        
                        elif n_rect.collidepoint(pos):
                            play_normal_click()
                            ap = active_popup["active_player"]
                            char = active_popup["char"]
                            dc = active_popup["dest_c"]
                            dr = active_popup["dest_r"]
                            hw_idx = active_popup["hit_warden_idx"]
                            tc = active_popup["throne_conquered"]
                        
                            active_popup = None
                            resolve_encounter(char, dc, dr, ap, True, hw_idx, tc, used_heart=False)

                    elif popup_type == "DYNAMIC_MENU":
                        m_rect, opts_rects = get_dynamic_menu_rects(active_popup["opts"])
                        for opt, r in opts_rects:
                            if r.collidepoint(pos):
                                play_normal_click()
                                if opt == "Resume Game":
                                    active_popup = None
                                elif opt == "Game Settings":
                                    active_popup = {"type": "DYNAMIC_MENU", "title": "GAME SETTINGS", "opts": ["Platform Settings", "Movement Mode", "Pass Screen Timer", "Music", "Sound Effects", "Back"]}
                                elif opt == "Movement Mode":
                                    active_popup = {"type": "MOVEMENT_SETTINGS", "title": "MOVEMENT MODE", "lines": []}
                                elif opt == "Player Settings":
                                    active_popup = {"type": "DYNAMIC_MENU", "title": "PLAYER SETTINGS", "opts": ["Rename Players", "Back"]}
                                elif opt == "Save / Load":
                                    active_popup = {"type": "DYNAMIC_MENU", "title": "SAVE / LOAD", "opts": ["Save Game", "Load Game", "Back"]}
                                elif opt == "Save Game":
                                    active_popup = {"type": "DYNAMIC_MENU", "title": "SAVE TO SLOT", "opts": ["Save Slot 1", "Save Slot 2", "Save Slot 3", "Back"]}
                                elif opt == "Load Game":
                                    active_popup = {"type": "DYNAMIC_MENU", "title": "LOAD FROM SLOT", "opts": ["Load Slot 1", "Load Slot 2", "Load Slot 3", "Back"]}
                                elif opt.startswith("Save Slot "):
                                    slot = opt[-1]
                                    success = save_game_state(slot)
                                    active_popup = {"type": "INFO", "title": "SAVE GAME", "lines": ["Game saved successfully!" if success else "Failed to save game."], "btn_text": "Okay"}
                                elif opt.startswith("Load Slot "):
                                    slot = opt[-1]
                                    success = load_game_state(slot)
                                    active_popup = {"type": "INFO", "title": "LOAD GAME", "lines": ["Game loaded successfully!" if success else "No saved game found in this slot."], "btn_text": "Okay"}
                                elif opt == "Platform Settings":
                                    active_popup = {"type": "PLATFORM_SETTINGS", "title": "PLATFORM MODE", "lines": []}
                                elif opt == "Pass Screen Timer":
                                    active_popup = {"type": "PASS_TIMER_SETTINGS", "title": "PASS TIMER", "lines": []}
                                elif opt == "Music":
                                    active_popup = {"type": "MUSIC_SETTINGS", "title": "MUSIC", "lines": []}
                                elif opt == "Sound Effects":
                                    active_popup = {"type": "SFX_SETTINGS", "title": "SOUND EFFECTS", "lines": []}
                                elif opt == "Rename Players":
                                    p1_name, p2_name = "", ""
                                    game_state = "ENTER_NAME_P1"
                                    pygame.key.stop_text_input()
                                    pygame.key.start_text_input()
                                    active_popup = None
                                elif opt == "Start Over":
                                    saved_1, saved_2 = p1_name, p2_name
                                    reset_game()
                                    p1_name, p2_name = saved_1, saved_2
                                    game_state = "SPACE_MEMORY_PROMPT"
                                    active_popup = None
                                elif opt == "End Game":
                                    reset_game()
                                    game_state = "HOME_MENU"
                                    active_popup = None
                                elif opt == "Close Game":
                                    active_popup = {"type": "CONFIRM_CLOSE", "title": "CLOSE GAME?", "lines": ["Close Inverse Dimensions?"]}
                                elif opt == "Back":
                                    if game_state == "HOME_MENU":
                                        active_popup = None
                                    else:
                                        active_popup = {"type": "DYNAMIC_MENU", "title": "MAIN MENU", "opts": ["Resume Game", "Game Settings", "Player Settings", "Save / Load", "Start Over", "End Game", "Close Game"]}
                                break
                        if not m_rect.collidepoint(pos):
                            active_popup = None

                    elif popup_type == "PLATFORM_SETTINGS":
                        pm_rect = pygame.Rect(screen_width//2 - modal_width//2, screen_height//2 - modal_height//2, modal_width, modal_height)
                        mob_rect = pygame.Rect(pm_rect.centerx - int(confirm_btn_width*0.4), pm_rect.top + 70, int(confirm_btn_width*0.8), confirm_btn_height)
                        desk_rect = pygame.Rect(pm_rect.centerx - int(confirm_btn_width*0.4), pm_rect.top + 70 + confirm_btn_height + 20, int(confirm_btn_width*0.8), confirm_btn_height)
                    
                        if mob_rect.collidepoint(pos) and platform_mode != "mobile":
                            play_start_click()
                            platform_mode = "mobile"
                            save_settings()
                            init_geometry()
                            load_all_sprites()
                            active_popup = None
                        elif desk_rect.collidepoint(pos) and platform_mode != "desktop":
                            play_start_click()
                            platform_mode = "desktop"
                            save_settings()
                            init_geometry()
                            load_all_sprites()
                            active_popup = None
                        elif not pm_rect.collidepoint(pos):
                            active_popup = None

                    elif popup_type == "MOVEMENT_SETTINGS":
                        m_h = int(screen_height * 0.55)
                        pm_rect = pygame.Rect(screen_width//2 - modal_width//2, screen_height//2 - m_h//2, modal_width, m_h)
                        b1_rect = pygame.Rect(pm_rect.centerx - int(confirm_btn_width*0.4), pm_rect.top + 70, int(confirm_btn_width*0.8), confirm_btn_height)
                        b2_rect = pygame.Rect(pm_rect.centerx - int(confirm_btn_width*0.4), pm_rect.top + 70 + confirm_btn_height + 20, int(confirm_btn_width*0.8), confirm_btn_height)
                        b3_rect = pygame.Rect(pm_rect.centerx - int(confirm_btn_width*0.4), pm_rect.top + 70 + (confirm_btn_height + 20)*2, int(confirm_btn_width*0.8), confirm_btn_height)
                    
                        if b1_rect.collidepoint(pos):
                            play_start_click()
                            movement_mode = "anywhere"
                            save_settings()
                            active_popup = None
                        elif b2_rect.collidepoint(pos):
                            play_start_click()
                            movement_mode = "straight"
                            save_settings()
                            active_popup = None
                        elif b3_rect.collidepoint(pos):
                            play_start_click()
                            movement_mode = "adjacent"
                            save_settings()
                            active_popup = None
                        elif not pm_rect.collidepoint(pos):
                            active_popup = None

                    elif popup_type == "PASS_TIMER_SETTINGS":
                        pt_rect = pygame.Rect(screen_width//2 - modal_width//2, screen_height//2 - modal_height//2, modal_width, modal_height)
                        on_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70, int(confirm_btn_width*0.8), confirm_btn_height)
                        off_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70 + confirm_btn_height + 20, int(confirm_btn_width*0.8), confirm_btn_height)
                    
                        if on_rect.collidepoint(pos):
                            play_start_click()
                            pass_screen_timer = "ON"
                            save_settings()
                            active_popup = None
                        elif off_rect.collidepoint(pos):
                            play_start_click()
                            pass_screen_timer = "OFF"
                            save_settings()
                            active_popup = None
                        elif not pt_rect.collidepoint(pos):
                            active_popup = None

                    elif popup_type == "MUSIC_SETTINGS":
                        pt_rect = pygame.Rect(screen_width//2 - modal_width//2, screen_height//2 - modal_height//2, modal_width, modal_height)
                        on_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70, int(confirm_btn_width*0.8), confirm_btn_height)
                        off_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70 + confirm_btn_height + 20, int(confirm_btn_width*0.8), confirm_btn_height)
                    
                        if on_rect.collidepoint(pos):
                            music_on = "ON"
                            play_start_click()
                            save_settings()
                            update_music()
                            active_popup = None
                        elif off_rect.collidepoint(pos):
                            music_on = "OFF"
                            play_start_click()
                            save_settings()
                            update_music()
                            active_popup = None
                        elif not pt_rect.collidepoint(pos):
                            active_popup = None

                    elif popup_type == "SFX_SETTINGS":
                        pt_rect = pygame.Rect(screen_width//2 - modal_width//2, screen_height//2 - modal_height//2, modal_width, modal_height)
                        on_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70, int(confirm_btn_width*0.8), confirm_btn_height)
                        off_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70 + confirm_btn_height + 20, int(confirm_btn_width*0.8), confirm_btn_height)
                    
                        if on_rect.collidepoint(pos):
                            sfx_on = "ON"
                            play_start_click()
                            save_settings()
                            active_popup = None
                        elif off_rect.collidepoint(pos):
                            sfx_on = "OFF"
                            save_settings()
                            active_popup = None
                        elif not pt_rect.collidepoint(pos):
                            active_popup = None

                    elif popup_type == "CONFIRM_CLOSE":
                        y_rect, n_rect = get_confirm_restart_rects()
                        if y_rect.collidepoint(pos):
                            running = False
                        elif n_rect.collidepoint(pos):
                            play_normal_click()
                            active_popup = None
                        
                    elif popup_type == "CRATE_INTERACTION":
                        y_rect, n_rect = get_confirm_restart_rects()
                        if y_rect.collidepoint(pos): 
                            play_start_click()
                            handle_crate_open(active_popup["crate_pos"], current_turn)
                        elif n_rect.collidepoint(pos): 
                            play_normal_click()
                            active_popup = None
                            game_state = "PLAY"
                        
                    elif popup_type == "CRATE_RESULT":
                        lines_count = len(active_popup.get("lines", []))
                        icon_size = int(confirm_btn_width * 0.3)
                        req_h = 185 + icon_size + (lines_count * 30) + confirm_btn_height
                        m_h = req_h
                        m_rect = pygame.Rect(screen_width // 2 - modal_width // 2, screen_height // 2 - m_h // 2, modal_width, m_h)
                        btn_rect = pygame.Rect(m_rect.centerx - int(confirm_btn_width * 0.4), m_rect.bottom - 30 - confirm_btn_height, int(confirm_btn_width * 0.8), confirm_btn_height)
                    
                        if btn_rect.collidepoint(pos):
                            play_normal_click()
                            if active_popup.get("crate_type") == "Skull":
                                p_id = current_turn
                                active_list = p1_chars if p_id == 1 else p2_chars
                                king = active_list[0]
                                king["grid_x"], king["grid_y"] = -1, -1
                                game_state = "SKULL_RESPAWN_CHOICE"
                            else:
                                game_state = "PLAY"
                            active_popup = None

                    else:
                        if modal_close_rect.collidepoint(pos):
                            play_normal_click()
                            active_popup = None
                    continue 

                if game_state == "THRONE_CRACK":
                    play_start_click()
                    if post_crack_state == "PASS_TURN": pass_screen_start_time = pygame.time.get_ticks()
                    game_state = post_crack_state
                    active_popup = post_crack_popup
                    post_crack_state, post_crack_popup = None, None
                    thronecrack_frame_index = 0
                    continue

                elif game_state == "RULES_SCREEN":
                    if rules_page_index > 0 and rules_prev_rect.collidepoint(pos):
                        play_normal_click()
                        rules_page_index -= 1
                    elif rules_next_rect.collidepoint(pos):
                        play_normal_click()
                        if rules_page_index < len(rules_pages) - 1:
                            rules_page_index += 1
                        else:
                            if rules_from_home:
                                game_state = "HOME_MENU"
                            else:
                                game_state = "SPACE_MEMORY_PROMPT"
                    continue

                elif game_state == "SPACE_MEMORY_PROMPT":
                    if enable_mem_rect.collidepoint(pos):
                        play_normal_click()
                        space_memory_enabled = True
                        game_state = "SETUP_PORTAL_P1"
                    elif disable_mem_rect.collidepoint(pos):
                        play_normal_click()
                        space_memory_enabled = False
                        game_state = "SETUP_PORTAL_P1"
                
                    if game_state == "SETUP_PORTAL_P1":
                        active_popup = {"title": f"WELCOME {p1_name.upper()}!", "lines": [f"Place your Portal on {p2_name}'s side.", "That's the bottom half of the board!", "Tap a cell, then confirm."], "btn_text": "Start Setup"}
                    continue

                elif game_state in ["WIN_P1", "WIN_P2"]:
                    if view_map_btn_rect.collidepoint(pos):
                        play_normal_click()
                        game_state = "VIEW_FINAL_BOARD"
                    elif restart_btn_rect.collidepoint(pos):
                        play_start_click()
                        reset_game()
                        game_state = "HOME_MENU"
                    continue

                elif game_state == "VIEW_FINAL_BOARD":
                    if return_win_rect.collidepoint(pos):
                        play_normal_click()
                        game_state = "WIN_P1" if final_winner == 1 else "WIN_P2"
                    elif exit_game_rect.collidepoint(pos): running = False
                    continue
            
                elif game_state == "ENTER_NAME_P1":
                    if p1_input_rect.collidepoint(pos):
                        play_normal_click()
                        # (no stop_text_input() here: stop+start in one tap can fail to reopen the keyboard on phones)
                        pygame.key.start_text_input()
                    elif p1_confirm_rect.collidepoint(pos):
                        play_start_click()
                        if not p1_name.strip(): p1_name = "Player 1"
                        pygame.key.stop_text_input()
                        game_state = "PASS_TO_PLAYER_2"
                    
                elif game_state == "PASS_TO_PLAYER_2":
                    play_normal_click()
                    game_state = "ENTER_NAME_P2"
                    pygame.key.stop_text_input()
                    pygame.key.start_text_input()
                
                elif game_state == "ENTER_NAME_P2":
                    if p2_input_rect.collidepoint(pos):
                        play_normal_click()
                        # (no stop_text_input() here: stop+start in one tap can fail to reopen the keyboard on phones)
                        pygame.key.start_text_input()
                    elif p2_confirm_rect.collidepoint(pos):
                        play_start_click()
                        if not p2_name.strip(): p2_name = "Player 2"
                        pygame.key.stop_text_input()
                        game_state = "SPACE_MEMORY_PROMPT"

                elif game_state == "SETUP_PORTAL_P1":
                    if confirm_btn_rect.collidepoint(pos) and p1_portal is not None:
                        play_start_click()
                        game_state = "PASS_TURN"
                        next_state_after_pass = "SETUP_PORTAL_P2"
                        pass_screen_start_time = pygame.time.get_ticks()
                    else:
                        c, r = get_grid_from_screen(pos[0], pos[1])
                        if 6 <= r < 11 and 0 <= c < COLS:
                            play_normal_click()
                            p1_portal = (c, r)

                elif game_state == "SETUP_PORTAL_P2":
                    if confirm_btn_rect.collidepoint(pos) and p2_portal is not None:
                        play_start_click()
                        game_state = "PASS_TURN"
                        next_state_after_pass = "SETUP_P1"
                        setup_mode = "wall"
                        pass_screen_start_time = pygame.time.get_ticks()
                    else:
                        c, r = get_grid_from_screen(pos[0], pos[1])
                        if 0 <= r < 5 and 0 <= c < COLS:
                            play_normal_click()
                            p2_portal = (c, r)

                elif game_state == "SETUP_P1":
                    rt_rect = random_tool_rect.inflate(-20, -10)
                    if wall_tool_rect.collidepoint(pos): play_normal_click(); setup_mode = "wall"
                    elif throne_tool_rect.collidepoint(pos): play_normal_click(); setup_mode = "throne"
                    elif crate_tool_rect.collidepoint(pos): play_normal_click(); setup_mode = "crate"
                    elif rt_rect.collidepoint(pos) or random_tool_rect.collidepoint(pos):
                        play_normal_click()
                        if p1_setup_state == "random":
                            randomize_player_board(1, p1_walls, p1_thrones, p1_crates, 0, 5, mode="fill")
                            p1_setup_state = "clear"
                        else:
                            randomize_player_board(1, p1_walls, p1_thrones, p1_crates, 0, 5, mode="clear")
                            p1_setup_state = "random"
                    elif confirm_btn_rect.collidepoint(pos):
                        p1_vals, p1_crates_vals = list(p1_thrones.values()), list(p1_crates.values())
                        if p1_vals.count("King") == 1 and p1_vals.count("Warden 1") == 1 and p1_vals.count("Warden 2") == 1 and "Heart" in p1_crates_vals and "Skull" in p1_crates_vals and len(p1_walls) == 10:
                            play_start_click()
                            init_player_positions(p1_thrones, p1_chars)
                            game_state = "PASS_TURN"
                            next_state_after_pass = "SETUP_P2"
                            setup_mode = "wall"
                            pass_screen_start_time = pygame.time.get_ticks()
                        else:
                            play_normal_click()
                            active_popup = {"title": "INCOMPLETE SETUP", "lines": ["You must place exactly 3 Thrones,", "10 Walls, and Both Crates."], "btn_text": "Okay"}
                    else: handle_setup_clicks(pos, 1, p1_walls, p1_thrones, p1_crates, 0, 5)

                elif game_state == "SETUP_P2":
                    rt_rect = random_tool_rect.inflate(-20, -10)
                    if wall_tool_rect.collidepoint(pos): play_normal_click(); setup_mode = "wall"
                    elif throne_tool_rect.collidepoint(pos): play_normal_click(); setup_mode = "throne"
                    elif crate_tool_rect.collidepoint(pos): play_normal_click(); setup_mode = "crate"
                    elif rt_rect.collidepoint(pos) or random_tool_rect.collidepoint(pos):
                        play_normal_click()
                        if p2_setup_state == "random":
                            randomize_player_board(2, p2_walls, p2_thrones, p2_crates, 6, 11, mode="fill")
                            p2_setup_state = "clear"
                        else:
                            randomize_player_board(2, p2_walls, p2_thrones, p2_crates, 6, 11, mode="clear")
                            p2_setup_state = "random"
                    elif confirm_btn_rect.collidepoint(pos):
                        p2_vals, p2_crates_vals = list(p2_thrones.values()), list(p2_crates.values())
                        if "King" in p2_vals and "Warden 1" in p2_vals and "Warden 2" in p2_vals and "Heart" in p2_crates_vals and "Skull" in p2_crates_vals and len(p2_walls) == 10:
                            play_start_click()
                            init_player_positions(p2_thrones, p2_chars)
                            game_state = "PASS_TURN"
                            next_state_after_pass = "PLAY"
                            current_turn = 1
                            actions_left = p1_lives * 2 
                            pass_screen_start_time = pygame.time.get_ticks()
                        else:
                            play_normal_click()
                            active_popup = {"title": "INCOMPLETE SETUP", "lines": ["You must place exactly 3 Thrones,", "10 Walls, and Both Crates."], "btn_text": "Okay"}
                    else: handle_setup_clicks(pos, 2, p2_walls, p2_thrones, p2_crates, 6, 11)

                elif game_state == "PASS_TURN":
                    is_ready = (pass_screen_timer == "OFF") or (pygame.time.get_ticks() - pass_screen_start_time >= PASS_DELAY_MS)
                    if is_ready and pass_btn_rect.collidepoint(pos): 
                        trigger_pass_transition()

                elif game_state == "CHOOSE_WARDEN_LOSS":
                    c, r = get_grid_from_screen(pos[0], pos[1])
                    active_list = p1_chars if sacrifice_player == 1 else p2_chars
                
                    for w_idx in [1, 2]:
                        w = active_list[w_idx]
                        if not w["sacrificed"] and w["grid_x"] == c and w["grid_y"] == r:
                            play_start_click()
                            w["sacrificed"] = True
                            w["grid_x"], w["grid_y"] = -1, -1
                            respawn_list = p1_wardens_to_respawn if sacrifice_player == 1 else p2_wardens_to_respawn
                            if w_idx in respawn_list: respawn_list.remove(w_idx)
                        
                            game_state = "PASS_TURN"
                            next_state_after_pass = "RESPAWN_CHOICE" if pending_capture else None
                            current_turn = 2 if current_turn == 1 and not pending_capture else 1 if current_turn == 2 and not pending_capture else current_turn
                            pass_screen_start_time = pygame.time.get_ticks()
                            break

                elif game_state == "RESPAWN_CHOICE":
                    friendly_thrones = p1_thrones if current_turn == 1 else p2_thrones
                    friendly_chars = p1_chars if current_turn == 1 else p2_chars
                    c, r = get_grid_from_screen(pos[0], pos[1])
                    cell = (c, r)
                    if cell in friendly_thrones:
                        if not any(c_char["grid_x"] == cell[0] and c_char["grid_y"] == cell[1] for c_char in friendly_chars if not c_char["sacrificed"]):
                            play_normal_click()
                            rc = friendly_chars[captured_char_idx]
                            rc["grid_x"], rc["grid_y"] = cell
                            rc["pixel_x"], rc["pixel_y"] = get_cell_center(*cell)
                        
                            if pending_capture:
                                pw = p1_wardens_to_respawn if pending_capture["warden_owner"] == 1 else p2_wardens_to_respawn
                                if pending_capture["warden_idx"] not in pw: pw.append(pending_capture["warden_idx"])
                                enemy_chars = p1_chars if pending_capture["warden_owner"] == 1 else p2_chars
                                enemy_chars[pending_capture["warden_idx"]]["grid_x"], enemy_chars[pending_capture["warden_idx"]]["grid_y"] = -1, -1
                                pending_capture = None

                            game_state = "PASS_TURN"
                            pass_screen_start_time = pygame.time.get_ticks()
                            current_turn = 2 if current_turn == 1 else 1
                            capturing_warden_pos = None
                        
                elif game_state == "SKULL_RESPAWN_CHOICE":
                    friendly_thrones = p1_thrones if current_turn == 1 else p2_thrones
                    friendly_chars = p1_chars if current_turn == 1 else p2_chars
                    c, r = get_grid_from_screen(pos[0], pos[1])
                    cell = (c, r)
                    if cell in friendly_thrones:
                        if not any(c_char["grid_x"] == cell[0] and c_char["grid_y"] == cell[1] for c_char in friendly_chars if not c_char["sacrificed"]):
                            play_normal_click()
                            rc = friendly_chars[0]
                            rc["grid_x"], rc["grid_y"] = cell
                            rc["pixel_x"], rc["pixel_y"] = get_cell_center(*cell)
                            selected_char_idx = 0
                            game_state = "PLAY"

                elif game_state == "WARDEN_RESPAWN":
                    friendly_thrones = p1_thrones if current_turn == 1 else p2_thrones
                    friendly_chars = p1_chars if current_turn == 1 else p2_chars
                    active_list = p1_wardens_to_respawn if current_turn == 1 else p2_wardens_to_respawn
                
                    c, r = get_grid_from_screen(pos[0], pos[1])
                    cell = (c, r)
                    if cell in friendly_thrones:
                        if not any(c_char["grid_x"] == cell[0] and c_char["grid_y"] == cell[1] for c_char in friendly_chars if not c_char["sacrificed"]):
                            play_normal_click()
                            warden_to_place = friendly_chars[active_warden_respawn_idx]
                            warden_to_place["grid_x"], warden_to_place["grid_y"] = cell
                            warden_to_place["pixel_x"], warden_to_place["pixel_y"] = get_cell_center(*cell)
                        
                            active_list.remove(active_warden_respawn_idx)
                            if len(active_list) > 0: active_warden_respawn_idx = active_list[0]
                            else:
                                game_state = "PLAY"
                                active_warden_respawn_idx = -1

                elif game_state in ["PLAY", "GUESS_THRONE_SELECT", "GUESS_THRONE_PUNISHMENT"]:
                    if game_state in ["PLAY", "GUESS_THRONE_SELECT"]:
                        if end_turn_btn_rect.collidepoint(pos):
                            play_start_click()
                            game_state = "PASS_TURN"
                            current_turn = 2 if current_turn == 1 else 1
                            pass_screen_start_time = pygame.time.get_ticks()
                            continue
                        
                        current_active_lives = p1_lives if current_turn == 1 else p2_lives
                        max_actions = current_active_lives * 2
                        can_guess = (actions_left == max_actions)

                        if guess_btn_rect.collidepoint(pos):
                            play_normal_click()
                            if game_state == "PLAY" and can_guess:
                                game_state = "GUESS_THRONE_SELECT"
                                actions_left -= 1
                                continue
                            elif game_state == "GUESS_THRONE_SELECT":
                                game_state = "PLAY"
                                actions_left += 1
                                continue

                        friendly_chars = p1_chars if current_turn == 1 else p2_chars
                        enemy_chars = p2_chars if current_turn == 1 else p1_chars
                        active_char = friendly_chars[selected_char_idx]
                        curr_loc = (active_char["grid_x"], active_char["grid_y"])
                    
                        on_portal = ("King" in active_char["name"] and p1_portal and p2_portal and (curr_loc == p1_portal or curr_loc == p2_portal))
                    
                        if on_portal and swap_portal_btn_rect.collidepoint(pos) and game_state == "PLAY" and actions_left > 0:
                            dest_portal = p2_portal if curr_loc == p1_portal else p1_portal
                            blocked_friendly = any(c_char["grid_x"] == dest_portal[0] and c_char["grid_y"] == dest_portal[1] for c_char in friendly_chars if not c_char["sacrificed"])
                            blocked_enemy_king = any("King" in ec["name"] and ec["grid_x"] == dest_portal[0] and ec["grid_y"] == dest_portal[1] for ec in enemy_chars if not ec["sacrificed"])
                        
                            if not blocked_friendly and not blocked_enemy_king:
                                play_normal_click()
                                actions_left -= 1
                                perform_portal_swap(active_char, current_turn)
                                continue

                    click_c, click_r = get_grid_from_screen(pos[0], pos[1])
                    clicked_grid_cell = None
                    if 0 <= click_c < COLS and 0 <= click_r < ROWS:
                        clicked_grid_cell = (click_c, click_r)

                    if clicked_grid_cell:
                        play_normal_click()
                        if game_state == "GUESS_THRONE_SELECT":
                            enemy_thrones = p2_thrones if current_turn == 1 else p1_thrones
                            discovered_thrones = p1_discovered_thrones if current_turn == 1 else p2_discovered_thrones
                        
                            if clicked_grid_cell in enemy_thrones and clicked_grid_cell not in discovered_thrones:
                                discovered_thrones.add(clicked_grid_cell)
                                del enemy_thrones[clicked_grid_cell]
                                game_state = "THRONE_CRACK"
                                if current_turn == 1:
                                    p2_lives -= 1
                                    sacrifice_player = 2
                                    if p2_lives <= 0: 
                                        final_winner = 1
                                        post_crack_state, post_crack_popup = "WIN_P1", None
                                    else:
                                        post_crack_state = "PASS_TURN"
                                        next_state_after_pass = "CHOOSE_WARDEN_LOSS"
                                        post_crack_popup = {"title": "CORRECT GUESS!", "lines": [f"{p1_name} correctly guessed a Throne!", f"{p2_name} has lost 1 Life.", f"Pass phone to {p2_name} to sacrifice a Warden."], "btn_text": "Sacrifice"}
                                else:
                                    p1_lives -= 1
                                    sacrifice_player = 1
                                    if p1_lives <= 0: 
                                        final_winner = 2
                                        post_crack_state, post_crack_popup = "WIN_P2", None
                                    else:
                                        post_crack_state = "PASS_TURN"
                                        next_state_after_pass = "CHOOSE_WARDEN_LOSS"
                                        post_crack_popup = {"title": "CORRECT GUESS!", "lines": [f"{p2_name} correctly guessed a Throne!", f"{p1_name} has lost 1 Life.", f"Pass phone to {p1_name} to sacrifice a Warden."], "btn_text": "Sacrifice"}
                            else:
                                friendly_walls = p1_walls if current_turn == 1 else p2_walls
                                if len(friendly_walls) > 0:
                                    game_state = "GUESS_THRONE_PUNISHMENT"
                                    active_popup = {"title": "INCORRECT GUESS!", "lines": ["That was not a hidden throne.", "You must now destroy one of your own walls!", "Tap a friendly wall to remove it."], "btn_text": "Acknowledge"}
                                else:
                                    game_state = "PLAY"
                                    active_popup = {"title": "INCORRECT GUESS!", "lines": ["That was not a hidden throne.", "You have no walls to destroy. Lucky you!"], "btn_text": "Continue"}
                            continue

                        elif game_state == "GUESS_THRONE_PUNISHMENT":
                            friendly_walls = p1_walls if current_turn == 1 else p2_walls
                            if clicked_grid_cell in friendly_walls:
                                friendly_walls.remove(clicked_grid_cell)
                                game_state = "PLAY"
                            continue

                        elif game_state == "PLAY":
                            clicked_friendly_idx = -1
                            for idx, char in enumerate(friendly_chars):
                                if char["grid_x"] == click_c and char["grid_y"] == click_r and not char["sacrificed"]:
                                    clicked_friendly_idx = idx
                                    break
                        
                            if clicked_friendly_idx != -1:
                                selected_char_idx = clicked_friendly_idx
                            else:
                                ax, ay = active_char["grid_x"], active_char["grid_y"]
                                dist = abs(click_c - ax) + abs(click_r - ay)
                            
                                is_valid_target = True
                                if movement_mode == "adjacent" and dist > 1:
                                    is_valid_target = False
                                elif movement_mode == "straight" and (click_c != ax and click_r != ay):
                                    is_valid_target = False
                                
                                if is_valid_target:
                                    if dist == 1:
                                        if actions_left > 0:
                                            status = check_valid_move(click_c, click_r, current_turn, active_char["name"])
                                            if status == "OK":
                                                mark_space_visited(current_turn, (click_c, click_r))
                                                execute_move(active_char, click_c, click_r, current_turn)
                                                actions_left -= 1
                                                play_walk_sound()
                                            elif status == "ENEMY_WALL":
                                                mark_space_visited(current_turn, (click_c, click_r))
                                                if current_turn == 1: p1_discovered_walls.add((click_c, click_r))
                                                else: p2_discovered_walls.add((click_c, click_r))
                                                actions_left -= 1
                                                play_walk_sound()
                                            elif status == "KING_COLLISION":
                                                mark_space_visited(current_turn, (click_c, click_r))
                                    elif dist > 1:
                                        if actions_left > 0:
                                            path = get_bfs_path((ax, ay), (click_c, click_r), current_turn, active_char["name"])
                                            if path:
                                                for step_c, step_r in path:
                                                    if actions_left <= 0: break
                                                    status = check_valid_move(step_c, step_r, current_turn, active_char["name"])
                                                
                                                    if status == "ENEMY_WALL":
                                                        mark_space_visited(current_turn, (step_c, step_r))
                                                        if current_turn == 1: p1_discovered_walls.add((step_c, step_r))
                                                        else: p2_discovered_walls.add((step_c, step_r))
                                                        actions_left -= 1
                                                        play_walk_sound()
                                                        break
                                                    elif status == "DISCOVERED_WALL":
                                                        break
                                                    elif status == "OK" or status == "KING_COLLISION":
                                                        mark_space_visited(current_turn, (step_c, step_r))
                                                        execute_move(active_char, step_c, step_r, current_turn)
                                                        actions_left -= 1
                                                        play_walk_sound()
                                                        if active_popup or game_state != "PLAY":
                                                            break

        # --- Render Step ---
        if game_state == "INTRO":
            screen.fill((0, 0, 0))
            elapsed = current_time - intro_start_time
        
            bg_alpha = max(0, min(255, int((elapsed / 6000.0) * 255)))
            bg_surface.set_alpha(bg_alpha)
            screen.blit(bg_surface, (0, 0))
        
            logo_alpha = max(0, min(255, int(((elapsed - 6000) / 7000.0) * 255)))
            if logo_sprite:
                logo_temp = logo_sprite.copy()
                logo_temp.fill((255, 255, 255, logo_alpha), special_flags=pygame.BLEND_RGBA_MULT)
                rect = logo_temp.get_rect(center=(screen_width // 2, screen_height // 2))
                screen.blit(logo_temp, rect)
            else:
                title_text = font_large.render("Inverse Dimensions", True, (255, 215, 0))
                title_text.set_alpha(logo_alpha)
                screen.blit(title_text, title_text.get_rect(center=(screen_width // 2, screen_height // 2)))
            
            sub_alpha = max(0, min(255, int(((elapsed - 6000) / 7000.0) * 255)))
            if sub_alpha > 0:
                prompt = font_small.render("Tap to Continue", True, (200, 200, 200))
                prompt.set_alpha(sub_alpha)
                screen.blit(prompt, prompt.get_rect(center=(screen_width // 2, int(screen_height * 0.85))))
        else:
            bg_surface.set_alpha(255)
            screen.blit(bg_surface, (0, 0))
        
        board_visible = True

        if game_state == "HOME_MENU":
            board_visible = False
            draw_logo(screen)
            for text, rect in home_menu_rects.items():
                draw_button(screen, rect, text, font_medium)

        elif game_state == "ENTER_NAME_P1":
            board_visible = False
            draw_logo(screen)
            draw_panel(screen, p1_input_rect)
            txt1 = font_medium.render(p1_name + ("|" if pygame.time.get_ticks() % 1000 < 500 else ""), True, (255, 255, 255))
            screen.blit(txt1, txt1.get_rect(center=p1_input_rect.center))
            label1 = font_small.render("Player 1 Name:", True, (200, 200, 200))
            screen.blit(label1, (p1_input_rect.left, p1_input_rect.top - 30))

            draw_button(screen, p1_confirm_rect, "Confirm P1 Name", font_medium)

        elif game_state == "PASS_TO_PLAYER_2":
            board_visible = False
            draw_logo(screen)
            title = font_large.render("PASS DEVICE", True, CLOSE_COLOR)
            sub = font_medium.render("Pass the phone to Player 2", True, (255, 255, 255))
            sub2 = font_small.render("Tap anywhere to continue", True, (200, 200, 200))
            screen.blit(title, title.get_rect(center=(screen_width // 2, screen_height * 0.4)))
            screen.blit(sub, sub.get_rect(center=(screen_width // 2, screen_height * 0.48)))
            screen.blit(sub2, sub2.get_rect(center=(screen_width // 2, screen_height * 0.6)))

        elif game_state == "ENTER_NAME_P2":
            board_visible = False
            draw_logo(screen)
            draw_panel(screen, p2_input_rect)
            txt2 = font_medium.render(p2_name + ("|" if pygame.time.get_ticks() % 1000 < 500 else ""), True, (255, 255, 255))
            screen.blit(txt2, txt2.get_rect(center=p2_input_rect.center))
            label2 = font_small.render("Player 2 Name:", True, (200, 200, 200))
            screen.blit(label2, (p2_input_rect.left, p2_input_rect.top - 30))

            draw_button(screen, p2_confirm_rect, "Start Setup Phase", font_medium)

        elif game_state == "RULES_SCREEN":
            board_visible = False
            draw_logo(screen)
            page_data = rules_pages[rules_page_index]
        
            y_offset = int(screen_height * 0.18)
            for line, l_type in page_data:
                if l_type == "title":
                    surf = font_large.render(line, True, (255, 215, 0))
                    screen.blit(surf, surf.get_rect(center=(screen_width // 2, y_offset)))
                    y_offset += int(screen_height * 0.06)
                elif l_type == "subtitle":
                    surf = font_medium.render(line, True, CONFIRM_COLOR)
                    screen.blit(surf, surf.get_rect(center=(screen_width // 2, y_offset)))
                    y_offset += int(screen_height * 0.04)
                else:
                    surf = font_small.render(line, True, (229, 229, 234))
                    screen.blit(surf, surf.get_rect(center=(screen_width // 2, y_offset)))
                    y_offset += int(screen_height * 0.035)

            if rules_page_index > 0:
                draw_button(screen, rules_prev_rect, "Back", font_medium)
        
            if rules_page_index < len(rules_pages) - 1:
                draw_button(screen, rules_next_rect, "Next", font_medium)
            else:
                if rules_from_home:
                    draw_button(screen, rules_next_rect, "Back to Menu", font_medium)
                else:
                    draw_button(screen, rules_next_rect, "Play", font_medium)

        elif game_state == "SPACE_MEMORY_PROMPT":
            board_visible = False
            draw_logo(screen)
            title = font_large.render("SPACE MEMORY", True, (255, 215, 0))
            screen.blit(title, title.get_rect(center=(screen_width // 2, int(screen_height * 0.22))))
        
            desc_text = [
                "When enabled, spaces you have previously visited",
                "on the enemy side of the board will remain marked",
                "so you can remember which locations have already",
                "been checked."
            ]
        
            y_offset = int(screen_height * 0.3)
            for line in desc_text:
                text_surf = font_small.render(line, True, (229, 229, 234))
                screen.blit(text_surf, text_surf.get_rect(center=(screen_width // 2, y_offset)))
                y_offset += int(screen_height * 0.04)
            
            draw_button(screen, enable_mem_rect, "Enable Space Memory", font_medium, override_type="button_standard.png")
            draw_button(screen, disable_mem_rect, "Disable Space Memory", font_medium, override_type="button_standard.png")

        elif board_visible and ("PORTAL" in game_state or "SETUP" in game_state or game_state in ["PLAY", "RESPAWN_CHOICE", "SKULL_RESPAWN_CHOICE", "WARDEN_RESPAWN", "GUESS_THRONE_SELECT", "GUESS_THRONE_PUNISHMENT", "VIEW_FINAL_BOARD", "THRONE_CRACK", "CHOOSE_WARDEN_LOSS"]):
            view_p = sacrifice_player if game_state == "CHOOSE_WARDEN_LOSS" else current_turn

            if game_state in ["PLAY", "GUESS_THRONE_SELECT", "GUESS_THRONE_PUNISHMENT"]:
                draw_action_medallion(screen, screen_width // 2, top_padding // 2, int(cell_size * 0.8), actions_left)

            for r in range(ROWS):
                for c in range(COLS):
                    tx, ty = get_cell_rect(c, r)
                
                    is_memorized = False
                    if space_memory_enabled and game_state in ["PLAY", "GUESS_THRONE_SELECT", "GUESS_THRONE_PUNISHMENT", "RESPAWN_CHOICE", "SKULL_RESPAWN_CHOICE", "WARDEN_RESPAWN", "THRONE_CRACK", "CHOOSE_WARDEN_LOSS"]:
                        if view_p == 1 and (c, r) in p1_visited_spaces: is_memorized = True
                        elif view_p == 2 and (c, r) in p2_visited_spaces: is_memorized = True

                    sprite_to_draw = None
                    if r < 5: sprite_to_draw = memorized_bluespace_sprite if is_memorized else bluespace_sprite
                    elif r > 5: sprite_to_draw = memorized_redspace_sprite if is_memorized else redspace_sprite
                    else: sprite_to_draw = yellowspace_sprite

                    if sprite_to_draw: screen.blit(sprite_to_draw, (tx, ty))
                    else:
                        pygame.draw.rect(screen, GRID_COLOR, pygame.Rect(tx, ty, cell_size, cell_size))
                        pygame.draw.rect(screen, (30,30,30), pygame.Rect(tx, ty, cell_size, cell_size).inflate(0, 0), 1)

                    cx, cy = tx + cell_size // 2, ty + cell_size // 2

                    if game_state == "VIEW_FINAL_BOARD":
                        if (c, r) in p1_walls or (c, r) in p2_walls:
                            if wall_sprite: screen.blit(wall_sprite, wall_sprite.get_rect(center=(cx, cy)))
                        if (c, r) in p1_crates:
                            sp = heart_crate_sprite if p1_crates[(c, r)] == "Heart" else skull_crate_sprite
                            if sp: screen.blit(sp, sp.get_rect(center=(cx, cy)))
                        if (c, r) in p2_crates:
                            sp = heart_crate_sprite if p2_crates[(c, r)] == "Heart" else skull_crate_sprite
                            if sp: screen.blit(sp, sp.get_rect(center=(cx, cy)))
                    else:
                        if game_state == "SETUP_P1":
                            if (c, r) in p1_walls and wall_sprite: screen.blit(wall_sprite, wall_sprite.get_rect(center=(cx, cy)))
                            if (c, r) in p1_crates:
                                sp = heart_crate_sprite if p1_crates[(c, r)] == "Heart" else skull_crate_sprite
                                if sp: screen.blit(sp, sp.get_rect(center=(cx, cy)))
                        elif game_state == "SETUP_P2":
                            if (c, r) in p2_walls and wall_sprite: screen.blit(wall_sprite, wall_sprite.get_rect(center=(cx, cy)))
                            if (c, r) in p2_crates:
                                sp = heart_crate_sprite if p2_crates[(c, r)] == "Heart" else skull_crate_sprite
                                if sp: screen.blit(sp, sp.get_rect(center=(cx, cy)))
                        elif game_state in ["PLAY", "RESPAWN_CHOICE", "SKULL_RESPAWN_CHOICE", "WARDEN_RESPAWN", "GUESS_THRONE_SELECT", "GUESS_THRONE_PUNISHMENT", "THRONE_CRACK", "CHOOSE_WARDEN_LOSS"]:
                            if view_p == 1:
                                if (c, r) in p1_walls and wall_sprite:
                                    if game_state == "GUESS_THRONE_PUNISHMENT": draw_pulsing_sprite(screen, wall_sprite, wall_sprite.get_rect(center=(cx, cy)))
                                    else: screen.blit(wall_sprite, wall_sprite.get_rect(center=(cx, cy)))
                                if (c, r) in p1_crates:
                                    sp = heart_crate_sprite if p1_crates[(c, r)] == "Heart" else skull_crate_sprite
                                    if sp: screen.blit(sp, sp.get_rect(center=(cx, cy)))
                            elif view_p == 2:
                                if (c, r) in p2_walls and wall_sprite:
                                    if game_state == "GUESS_THRONE_PUNISHMENT": draw_pulsing_sprite(screen, wall_sprite, wall_sprite.get_rect(center=(cx, cy)))
                                    else: screen.blit(wall_sprite, wall_sprite.get_rect(center=(cx, cy)))
                                if (c, r) in p2_crates:
                                    sp = heart_crate_sprite if p2_crates[(c, r)] == "Heart" else skull_crate_sprite
                                    if sp: screen.blit(sp, sp.get_rect(center=(cx, cy)))
                        
                            if view_p == 1 and (c, r) in p1_discovered_walls and (c, r) in p2_walls:
                                if wall_sprite: screen.blit(wall_sprite, wall_sprite.get_rect(center=(cx, cy)))
                            elif view_p == 2 and (c, r) in p2_discovered_walls and (c, r) in p1_walls:
                                if wall_sprite: screen.blit(wall_sprite, wall_sprite.get_rect(center=(cx, cy)))

            if game_state == "VIEW_FINAL_BOARD":
                for throne_pos in p1_thrones.keys():
                    cc = get_cell_center(*throne_pos)
                    standing_char = next((c for c in p1_chars if not c["sacrificed"] and c["grid_x"] == throne_pos[0] and c["grid_y"] == throne_pos[1]), None)
                    sprite = p1_setup_throne_sprites.get(standing_char["name"], empty_throne_sprite) if standing_char else empty_throne_sprite
                    if sprite: screen.blit(sprite, sprite.get_rect(center=cc))
                
                for throne_pos in p2_thrones.keys():
                    cc = get_cell_center(*throne_pos)
                    standing_char = next((c for c in p2_chars if not c["sacrificed"] and c["grid_x"] == throne_pos[0] and c["grid_y"] == throne_pos[1]), None)
                    sprite = p2_setup_throne_sprites.get(standing_char["name"], empty_throne_sprite) if standing_char else empty_throne_sprite
                    if sprite: screen.blit(sprite, sprite.get_rect(center=cc))
                
                for char in p1_chars + p2_chars:
                    if char["grid_x"] != -1 and not char["sacrificed"]:
                        if (char in p1_chars) and ((char["grid_x"], char["grid_y"]) in p1_thrones): continue
                        if (char in p2_chars) and ((char["grid_x"], char["grid_y"]) in p2_thrones): continue
                        sprite = char["sprites"]["resting"]
                        if sprite: screen.blit(sprite, sprite.get_rect(center=(int(char["pixel_x"]), int(char["pixel_y"]))))
                    
                for p_pos in [p1_portal, p2_portal]:
                    if p_pos:
                        cc = get_cell_center(*p_pos)
                        if portal_frames:
                            p_sprite = portal_frames[portal_frame_index]
                            screen.blit(p_sprite, p_sprite.get_rect(center=cc))
            
                draw_button(screen, return_win_rect, "Return to Win Screen", font_medium)
                draw_button(screen, exit_game_rect, "Exit Game", font_medium)

            else:
                thrones_to_draw = p1_thrones if (game_state == "SETUP_P1" or (game_state in ["PLAY", "RESPAWN_CHOICE", "SKULL_RESPAWN_CHOICE", "WARDEN_RESPAWN", "GUESS_THRONE_SELECT", "GUESS_THRONE_PUNISHMENT", "THRONE_CRACK", "CHOOSE_WARDEN_LOSS"] and view_p == 1)) else p2_thrones
                setup_assets = p1_setup_throne_sprites if (game_state == "SETUP_P1" or (game_state in ["PLAY", "RESPAWN_CHOICE", "SKULL_RESPAWN_CHOICE", "WARDEN_RESPAWN", "GUESS_THRONE_SELECT", "GUESS_THRONE_PUNISHMENT", "THRONE_CRACK", "CHOOSE_WARDEN_LOSS"] and view_p == 1)) else p2_setup_throne_sprites
                friendly_chars = p1_chars if (game_state == "SETUP_P1" or (game_state in ["PLAY", "RESPAWN_CHOICE", "SKULL_RESPAWN_CHOICE", "WARDEN_RESPAWN", "GUESS_THRONE_SELECT", "GUESS_THRONE_PUNISHMENT", "THRONE_CRACK", "CHOOSE_WARDEN_LOSS"] and view_p == 1)) else p2_chars
            
                for throne_pos, occupant in thrones_to_draw.items():
                    cc = get_cell_center(*throne_pos)
                    if "SETUP" in game_state:
                        asset_key = occupant if occupant else "Empty"
                        sprite = setup_assets.get(asset_key, empty_throne_sprite)
                    else:
                        standing_char = next((c for c in friendly_chars if not c["sacrificed"] and c["grid_x"] == throne_pos[0] and c["grid_y"] == throne_pos[1]), None)
                        sprite = setup_assets.get(standing_char["name"], throne_sprite) if standing_char else throne_sprite
                
                    if sprite:
                        r = sprite.get_rect(center=cc)
                        pulse = False
                        if game_state in ["RESPAWN_CHOICE", "SKULL_RESPAWN_CHOICE", "WARDEN_RESPAWN"]:
                            if "SETUP" not in game_state and not standing_char:
                                pulse = True
                        elif game_state == "PLAY" and standing_char and friendly_chars.index(standing_char) == selected_char_idx:
                            pulse = True
                        elif game_state == "CHOOSE_WARDEN_LOSS" and view_p == sacrifice_player:
                            if standing_char and "Warden" in standing_char["name"]:
                                pulse = True

                        if pulse: draw_pulsing_sprite(screen, sprite, r)
                        else: screen.blit(sprite, r)

                disc_thrones = p1_discovered_thrones if view_p == 1 else p2_discovered_thrones
                enemy_setup_assets = p2_setup_throne_sprites if view_p == 1 else p1_setup_throne_sprites
                enemy_thrones = p2_thrones if view_p == 1 else p1_thrones
                enemy_chars = p2_chars if view_p == 1 else p1_chars

                for p_pos in [p1_portal, p2_portal]:
                    if p_pos:
                        cc = get_cell_center(*p_pos)
                        if portal_frames:
                            p_sprite = portal_frames[portal_frame_index]
                            screen.blit(p_sprite, p_sprite.get_rect(center=cc))

                if "SETUP" not in game_state and "PORTAL" not in game_state:
                    active_list, enemy_list = (p1_chars, p2_chars) if view_p == 1 else (p2_chars, p1_chars)
                    friendly_thrones, enemy_thrones = (p1_thrones, p2_thrones) if view_p == 1 else (p2_thrones, p1_thrones)
                
                    for i, char in enumerate(active_list):
                        if char["grid_x"] == -1 or char["sacrificed"]: continue 
                        if game_state == "RESPAWN_CHOICE" and i == captured_char_idx: continue
                        if (char["grid_x"], char["grid_y"]) in friendly_thrones: continue
                    
                        sprite = char["sprites"]["resting"]
                        if sprite:
                            r = sprite.get_rect(center=(int(char["pixel_x"]), int(char["pixel_y"])))
                            pulse = False
                            if game_state == "PLAY" and i == selected_char_idx:
                                pulse = True
                            elif game_state == "CHOOSE_WARDEN_LOSS" and view_p == sacrifice_player and "Warden" in char["name"]:
                                pulse = True
                            
                            if pulse: draw_pulsing_sprite(screen, sprite, r)
                            else: screen.blit(sprite, r)
                
                    for ec in enemy_list:
                        if ec["grid_x"] == -1 or ec["sacrificed"]: continue 
                        pos = (ec["grid_x"], ec["grid_y"])
                        visible = False
                        if "King" in ec["name"]:
                            if view_p == 1 and ec["grid_y"] <= 5: visible = True
                            elif view_p == 2 and ec["grid_y"] >= 5: visible = True
                            if pos in temp_revealed_kings: visible = True
                        if game_state == "RESPAWN_CHOICE" and capturing_warden_pos == pos: visible = True
                    
                        if visible:
                            if pos in enemy_thrones and pos not in disc_thrones:
                                if "King" in ec["name"] and pos in temp_revealed_kings:
                                    sprite = enemy_setup_assets.get("King", throne_sprite)
                                    if sprite:
                                        r = sprite.get_rect(center=(int(ec["pixel_x"]), int(ec["pixel_y"])))
                                        screen.blit(sprite, r)
                                elif capturing_warden_pos == pos:
                                    sprite = ec["sprites"]["resting"]
                                    if sprite:
                                        r = sprite.get_rect(center=(int(ec["pixel_x"]), int(ec["pixel_y"])))
                                        screen.blit(sprite, r)
                            else:
                                sprite = ec["sprites"]["resting"]
                                if sprite: 
                                    r = sprite.get_rect(center=(int(ec["pixel_x"]), int(ec["pixel_y"])))
                                    screen.blit(sprite, r)

                if "SETUP_PORTAL" in game_state:
                    active_setup_p = p1_name if game_state == "SETUP_PORTAL_P1" else p2_name
                    target_side = f"{p2_name}'s Side (Bottom)" if game_state == "SETUP_PORTAL_P1" else f"{p1_name}'s Side (Top)"
                    portal_set = p1_portal if game_state == "SETUP_PORTAL_P1" else p2_portal
                
                    task_str = f"{active_setup_p}: Place Portal on {target_side}" if not portal_set else f"{active_setup_p}: Portal Placed! Confirm Placement."
                    screen.blit(font_medium.render(f"{active_setup_p} Setup", True, (255, 255, 255)), (20, 15))
                    screen.blit(font_small.render(task_str, True, (255, 215, 0)), (20, 45))
                
                    draw_button(screen, confirm_btn_rect, "Confirm Portal Placement", font_medium, disabled=(not portal_set))

                elif "SETUP" in game_state:
                    active_p_name = p1_name if game_state == "SETUP_P1" else p2_name
                    task_str = get_current_setup_task(1 if game_state == "SETUP_P1" else 2, active_p_name)
                    screen.blit(font_medium.render(f"{active_p_name} Setup", True, (255, 255, 255)), (20, 15))
                    screen.blit(font_small.render(task_str, True, (255, 215, 0)), (20, 45))
                
                    draw_button(screen, wall_tool_rect, "Wall", font_small, override_type="button_important.png" if setup_mode=="wall" else "button_standard.png")
                    draw_button(screen, throne_tool_rect, "Throne", font_small, override_type="button_important.png" if setup_mode=="throne" else "button_standard.png")
                    draw_button(screen, crate_tool_rect, "Crate", font_small, override_type="button_important.png" if setup_mode=="crate" else "button_standard.png")
                
                    rt_rect = random_tool_rect.inflate(-20, -10)
                    random_state = p1_setup_state if game_state == "SETUP_P1" else p2_setup_state
                    draw_button(screen, rt_rect, "Random" if random_state == "random" else "Clear", font_small, override_type="button_standard.png")
                
                    dark_surf = pygame.Surface((rt_rect.width, rt_rect.height), pygame.SRCALPHA)
                    pygame.draw.rect(dark_surf, (0, 0, 0, 100), dark_surf.get_rect(), border_radius=12)
                    screen.blit(dark_surf, rt_rect.topleft)
                
                    p_vals, p_crates_vals = (list(p1_thrones.values()), list(p1_crates.values())) if game_state == "SETUP_P1" else (list(p2_thrones.values()), list(p2_crates.values()))
                    w_len = len(p1_walls) if game_state == "SETUP_P1" else len(p2_walls)
                    is_ready = (p_vals.count("King") == 1 and p_vals.count("Warden 1") == 1 and p_vals.count("Warden 2") == 1 and "Heart" in p_crates_vals and "Skull" in p_crates_vals and w_len == 10)
                
                    draw_button(screen, confirm_btn_rect, "Lock Setup", font_medium, disabled=not is_ready)

                elif game_state in ["PLAY", "GUESS_THRONE_SELECT", "GUESS_THRONE_PUNISHMENT"]:
                    active_p_name = p1_name if current_turn == 1 else p2_name
                    screen.blit(font_small.render(f"{active_p_name}'s Turn", True, (255, 255, 255)), (20, 15))
                
                    if game_state == "GUESS_THRONE_SELECT": screen.blit(font_small.render("GUESS MODE: Tap an enemy tile to guess throne", True, (255, 215, 0)), (20, 115))
                    elif game_state == "GUESS_THRONE_PUNISHMENT": screen.blit(font_small.render("PUNISHMENT: Tap your own wall to destroy it", True, CLOSE_COLOR), (20, 115))
                    
                    found_count = len(p1_discovered_thrones if current_turn == 1 else p2_discovered_thrones)
                    for idx in range(found_count):
                        if throne_icon_ui:
                            screen.blit(throne_icon_ui, (20 + idx * int(cell_size * 0.6), 45))
                
                    current_active_lives = p1_lives if current_turn == 1 else p2_lives
                    draw_hearts(screen, 20 + int(cell_size * 0.25), 85, current_active_lives)

                    max_actions = current_active_lives * 2
                    can_guess = (actions_left == max_actions)

                    if game_state == "GUESS_THRONE_SELECT":
                        draw_button(screen, guess_btn_rect, "Cancel", font_medium, override_type="button_standard.png")
                    else:
                        draw_button(screen, guess_btn_rect, "Guess", font_medium, disabled=not can_guess, override_type="button_standard.png")

                    draw_button(screen, end_turn_btn_rect, "End Turn", font_medium, override_type="button_danger.png")

                    friendly_chars = p1_chars if current_turn == 1 else p2_chars
                    active_char = friendly_chars[selected_char_idx]
                    curr_loc = (active_char["grid_x"], active_char["grid_y"])
                    on_portal = ("King" in active_char["name"] and p1_portal and p2_portal and (curr_loc == p1_portal or curr_loc == p2_portal))
                
                    draw_button(screen, swap_portal_btn_rect, "Portal", font_medium, disabled=not (on_portal and actions_left>0), override_type="button_standard.png")
                
                    has_heart = p1_has_heart_stored if current_turn == 1 else p2_has_heart_stored
                    draw_button(screen, use_heart_btn_rect, "Heart", font_medium, disabled=not has_heart, override_type="button_standard.png")
                
                elif game_state in ["RESPAWN_CHOICE", "SKULL_RESPAWN_CHOICE"]:
                    msg = "CAPTURED! SELECT RESPAWN THRONE" if game_state == "RESPAWN_CHOICE" else "SKULL CRATE! SELECT RESPAWN THRONE"
                    color_to_use = CLOSE_COLOR if game_state == "RESPAWN_CHOICE" else (255, 215, 0)
                    screen.blit(font_medium.render(msg, True, color_to_use), (20, 15))

                elif game_state == "WARDEN_RESPAWN":
                    screen.blit(font_medium.render("REDEPLOY YOUR WARDEN!", True, (255, 215, 0)), (20, 15))
                    screen.blit(font_small.render("Tap an empty friendly throne to spawn warden.", True, (255, 255, 255)), (20, 45))

                elif game_state == "CHOOSE_WARDEN_LOSS":
                    screen.blit(font_medium.render("SACRIFICE A WARDEN!", True, CLOSE_COLOR), (20, 15))
                    sac_name = p1_name if sacrifice_player == 1 else p2_name
                    screen.blit(font_small.render(f"{sac_name}, tap a highlighted Warden to eliminate them.", True, (255, 255, 255)), (20, 45))

        # --- PASS SCREENS ---
        if "PASS" in game_state and game_state != "PASS_TO_PLAYER_2":
            remaining = max(0, PASS_DELAY_MS - (pygame.time.get_ticks() - pass_screen_start_time))
            seconds_left = (remaining + 999) // 1000
        
            target_p = p1_name if current_turn == 1 else p2_name
            title_text = "PASS THE PHONE!"
            if next_state_after_pass == "CHOOSE_WARDEN_LOSS": sub_lbl = f"{p1_name if sacrifice_player == 1 else p2_name}: Sacrifice a Warden!"
            elif next_state_after_pass in ["SETUP_PORTAL_P2", "SETUP_P2"]: sub_lbl = f"Hand it to {p2_name}"
            elif next_state_after_pass in ["SETUP_P1", "PLAY"]: sub_lbl = f"Hand it to {p1_name}"
            elif next_state_after_pass == "RESPAWN_CHOICE": sub_lbl = f"{target_p}: Choose your Respawn Throne"
            else: sub_lbl = f"Hand it to {target_p}"

            screen.blit(dim_overlay, (0, 0))
            txt = font_large.render(title_text, True, (255, 215, 0))
            sub = font_medium.render(sub_lbl, True, (255, 255, 255))
            screen.blit(txt, txt.get_rect(center=(screen_width // 2, screen_height // 2 - 60)))
            screen.blit(sub, sub.get_rect(center=(screen_width // 2, screen_height // 2 - 10)))
        
            btn_lbl_text = f"Wait {seconds_left}s" if (pass_screen_timer == "ON" and remaining > 0) else "I am ready"
            draw_button(screen, pass_btn_rect, btn_lbl_text, font_medium, disabled=(pass_screen_timer == "ON" and remaining > 0), override_type="button_standard.png")

        # --- END GAME SCREENS ---
        elif game_state in ["WIN_P1", "WIN_P2"]:
            draw_logo(screen)
            winner_text = f"{p1_name.upper()} WINS!" if game_state == "WIN_P1" else f"{p2_name.upper()} WINS!"
            title = font_large.render(winner_text, True, CONFIRM_COLOR)
            sub = font_medium.render("All 3 Enemy Thrones Conquered!", True, (255, 255, 255))
            screen.blit(title, title.get_rect(center=(screen_width // 2, screen_height // 2 - 80)))
            sub_rect = sub.get_rect(center=(screen_width // 2, screen_height // 2 - 30))
            screen.blit(sub, sub_rect)
        
            draw_button(screen, view_map_btn_rect, "See End Map", font_medium, override_type="button_standard.png")
            draw_button(screen, restart_btn_rect, "Play Again", font_medium)

        # --- THRONE CRACK OVERLAY ---
        if game_state == "THRONE_CRACK":
            screen.blit(dim_overlay, (0, 0))
            if thronecrack_frames:
                now = pygame.time.get_ticks()
                if now - thronecrack_last_update > THRONECRACK_FRAME_TIME_MS:
                    thronecrack_frame_index = (thronecrack_frame_index + 1) % len(thronecrack_frames)
                    thronecrack_last_update = now
                frame_to_draw = thronecrack_frames[thronecrack_frame_index]
                tc_rect = frame_to_draw.get_rect(center=(screen_width // 2, screen_height // 2))
                screen.blit(frame_to_draw, tc_rect)
                y_pos = tc_rect.bottom + 30
            else:
                txt = font_large.render("THRONE CRACKED!", True, CONFIRM_COLOR)
                screen.blit(txt, txt.get_rect(center=(screen_width // 2, screen_height // 2)))
                y_pos = screen_height // 2 + 60
            
            sub_txt = font_medium.render("Tap anywhere to continue", True, (255, 255, 255))
            screen.blit(sub_txt, sub_txt.get_rect(center=(screen_width // 2, y_pos)))

        # --- POP-UP MODAL OVERLAY RENDER ---
        elif active_popup:
            screen.blit(dim_overlay, (0, 0))
            popup_type = active_popup.get("type", "INFO")

            if popup_type == "THRONE_CHOICE":
                m_rect, opts_rects = get_throne_choice_rects()
                draw_panel(screen, m_rect)
                title_surf = font_medium.render("SELECT THRONE", True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(m_rect.centerx, m_rect.top + 30)))
                assets = p1_setup_throne_sprites if active_popup["player"] == 1 else p2_setup_throne_sprites
            
                for opt, r in opts_rects:
                    draw_button(screen, r, opt, font_medium, override_type="button_standard.png")
                    sprite = assets.get(opt, empty_throne_sprite) if opt != "Empty" else empty_throne_sprite
                    if sprite: screen.blit(sprite, sprite.get_rect(midleft=(r.left + 20, r.centery)))
                
            elif popup_type == "CRATE_CHOICE":
                m_rect, hc_rect, sc_rect = get_crate_choice_rects()
                draw_panel(screen, m_rect)
                title_surf = font_medium.render("SELECT CRATE TYPE", True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(m_rect.centerx, m_rect.top + 30)))
            
                if modal_heart_sprite: screen.blit(modal_heart_sprite, modal_heart_sprite.get_rect(center=hc_rect.center))
                hl = font_small.render("Heart", True, (255, 255, 255))
                screen.blit(hl, hl.get_rect(center=(hc_rect.centerx, hc_rect.bottom + 15)))

                if modal_skull_sprite: screen.blit(modal_skull_sprite, modal_skull_sprite.get_rect(center=sc_rect.center))
                sl = font_small.render("Skull", True, (255, 255, 255))
                screen.blit(sl, sl.get_rect(center=(sc_rect.centerx, sc_rect.bottom + 15)))

            elif popup_type == "HEART_PROMPT":
                draw_panel(screen, modal_rect)
                title_surf = font_medium.render(active_popup["title"], True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(modal_rect.centerx, modal_rect.top + 30)))

                y_offset = modal_rect.top + 75
                for line in active_popup["lines"]:
                    line_surf = font_small.render(line, True, (229, 229, 234))
                    screen.blit(line_surf, line_surf.get_rect(center=(modal_rect.centerx, y_offset)))
                    y_offset += 28

                y_rect, n_rect = get_confirm_restart_rects()
                draw_button(screen, y_rect, "Yes", font_medium)
                draw_button(screen, n_rect, "No", font_medium)
            
            elif popup_type == "DYNAMIC_MENU":
                m_rect, opts_rects = get_dynamic_menu_rects(active_popup["opts"])
                draw_panel(screen, m_rect)
                title_surf = font_medium.render(active_popup["title"], True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(m_rect.centerx, m_rect.top + 30)))
            
                for opt, r in opts_rects:
                    draw_button(screen, r, opt, font_medium)

            elif popup_type == "PLATFORM_SETTINGS":
                pm_rect = pygame.Rect(screen_width//2 - modal_width//2, screen_height//2 - modal_height//2, modal_width, modal_height)
                draw_panel(screen, pm_rect)
                title_surf = font_medium.render("PLATFORM MODE", True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(pm_rect.centerx, pm_rect.top + 30)))

                mob_rect = pygame.Rect(pm_rect.centerx - int(confirm_btn_width*0.4), pm_rect.top + 70, int(confirm_btn_width*0.8), confirm_btn_height)
                desk_rect = pygame.Rect(pm_rect.centerx - int(confirm_btn_width*0.4), pm_rect.top + 70 + confirm_btn_height + 20, int(confirm_btn_width*0.8), confirm_btn_height)
            
                draw_button(screen, mob_rect, "Mobile Mode (Large UI)", font_medium, override_type="button_important.png" if platform_mode=="mobile" else "button_standard.png")
                draw_button(screen, desk_rect, "Desktop Mode (Small UI)", font_medium, override_type="button_important.png" if platform_mode=="desktop" else "button_standard.png")

            elif popup_type == "MOVEMENT_SETTINGS":
                m_h = int(screen_height * 0.55)
                pm_rect = pygame.Rect(screen_width//2 - modal_width//2, screen_height//2 - m_h//2, modal_width, m_h)
                draw_panel(screen, pm_rect)
                title_surf = font_medium.render("MOVEMENT MODE", True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(pm_rect.centerx, pm_rect.top + 30)))

                b1_rect = pygame.Rect(pm_rect.centerx - int(confirm_btn_width*0.4), pm_rect.top + 70, int(confirm_btn_width*0.8), confirm_btn_height)
                b2_rect = pygame.Rect(pm_rect.centerx - int(confirm_btn_width*0.4), pm_rect.top + 70 + confirm_btn_height + 20, int(confirm_btn_width*0.8), confirm_btn_height)
                b3_rect = pygame.Rect(pm_rect.centerx - int(confirm_btn_width*0.4), pm_rect.top + 70 + (confirm_btn_height + 20)*2, int(confirm_btn_width*0.8), confirm_btn_height)
            
                draw_button(screen, b1_rect, "Anywhere (Auto-Path)", font_medium, override_type="button_important.png" if movement_mode=="anywhere" else "button_standard.png")
                draw_button(screen, b2_rect, "Straight Lines Only", font_medium, override_type="button_important.png" if movement_mode=="straight" else "button_standard.png")
                draw_button(screen, b3_rect, "Adjacent Only (Classic)", font_medium, override_type="button_important.png" if movement_mode=="adjacent" else "button_standard.png")

            elif popup_type == "PASS_TIMER_SETTINGS":
                pt_rect = pygame.Rect(screen_width//2 - modal_width//2, screen_height//2 - modal_height//2, modal_width, modal_height)
                draw_panel(screen, pt_rect)
                title_surf = font_medium.render("PASS SCREEN TIMER", True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(pt_rect.centerx, pt_rect.top + 30)))

                on_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70, int(confirm_btn_width*0.8), confirm_btn_height)
                off_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70 + confirm_btn_height + 20, int(confirm_btn_width*0.8), confirm_btn_height)
            
                draw_button(screen, on_rect, "Timer ON (Forced Countdown)", font_medium, override_type="button_important.png" if pass_screen_timer=="ON" else "button_standard.png")
                draw_button(screen, off_rect, "Timer OFF (Instant Skip)", font_medium, override_type="button_important.png" if pass_screen_timer=="OFF" else "button_standard.png")

            elif popup_type == "MUSIC_SETTINGS":
                pt_rect = pygame.Rect(screen_width//2 - modal_width//2, screen_height//2 - modal_height//2, modal_width, modal_height)
                draw_panel(screen, pt_rect)
                title_surf = font_medium.render("MUSIC SETTINGS", True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(pt_rect.centerx, pt_rect.top + 30)))

                on_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70, int(confirm_btn_width*0.8), confirm_btn_height)
                off_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70 + confirm_btn_height + 20, int(confirm_btn_width*0.8), confirm_btn_height)
            
                draw_button(screen, on_rect, "Music ON", font_medium, override_type="button_important.png" if music_on=="ON" else "button_standard.png")
                draw_button(screen, off_rect, "Music OFF", font_medium, override_type="button_important.png" if music_on=="OFF" else "button_standard.png")

            elif popup_type == "SFX_SETTINGS":
                pt_rect = pygame.Rect(screen_width//2 - modal_width//2, screen_height//2 - modal_height//2, modal_width, modal_height)
                draw_panel(screen, pt_rect)
                title_surf = font_medium.render("SOUND EFFECTS", True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(pt_rect.centerx, pt_rect.top + 30)))

                on_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70, int(confirm_btn_width*0.8), confirm_btn_height)
                off_rect = pygame.Rect(pt_rect.centerx - int(confirm_btn_width*0.4), pt_rect.top + 70 + confirm_btn_height + 20, int(confirm_btn_width*0.8), confirm_btn_height)
            
                draw_button(screen, on_rect, "SFX ON", font_medium, override_type="button_important.png" if sfx_on=="ON" else "button_standard.png")
                draw_button(screen, off_rect, "SFX OFF", font_medium, override_type="button_important.png" if sfx_on=="OFF" else "button_standard.png")

            elif popup_type == "CONFIRM_CLOSE":
                draw_panel(screen, modal_rect)
                title_surf = font_medium.render(active_popup["title"], True, CLOSE_COLOR)
                screen.blit(title_surf, title_surf.get_rect(center=(modal_rect.centerx, modal_rect.top + 30)))

                y_offset = modal_rect.top + 75
                for line in active_popup["lines"]:
                    line_surf = font_small.render(line, True, (229, 229, 234))
                    screen.blit(line_surf, line_surf.get_rect(center=(modal_rect.centerx, y_offset)))
                    y_offset += 28

                y_rect, n_rect = get_confirm_restart_rects()
                draw_button(screen, y_rect, "Yes", font_medium, override_type="button_small.png")
                draw_button(screen, n_rect, "No", font_medium, override_type="button_small.png")

            elif popup_type == "CRATE_INTERACTION":
                draw_panel(screen, modal_rect)
                title_surf = font_medium.render(active_popup["title"], True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(modal_rect.centerx, modal_rect.top + 30)))

                y_offset = modal_rect.top + 75
                for line in active_popup["lines"]:
                    line_surf = font_small.render(line, True, (229, 229, 234))
                    screen.blit(line_surf, line_surf.get_rect(center=(modal_rect.centerx, y_offset)))
                    y_offset += 28

                y_rect, n_rect = get_confirm_restart_rects()
                draw_button(screen, y_rect, "Open", font_medium, override_type="button_small.png")
                draw_button(screen, n_rect, "Leave Closed", font_medium, override_type="button_small.png")
            
            elif popup_type == "CRATE_RESULT":
                c_color = CONFIRM_COLOR if active_popup.get("crate_type") == "Heart" else CLOSE_COLOR
            
                lines_count = len(active_popup.get("lines", []))
                icon_size = int(confirm_btn_width * 0.3)
                req_h = 185 + icon_size + (lines_count * 30) + confirm_btn_height
                m_h = req_h
                m_rect = pygame.Rect(screen_width // 2 - modal_width // 2, screen_height // 2 - m_h // 2, modal_width, m_h)
            
                draw_panel(screen, m_rect)
            
                title_surf = font_medium.render(active_popup["title"], True, c_color)
                screen.blit(title_surf, title_surf.get_rect(center=(m_rect.centerx, m_rect.top + 40)))

                frames = heart_open_frames if active_popup.get("crate_type") == "Heart" else skull_open_frames
                icon = None
                if frames:
                    now = pygame.time.get_ticks()
                    if now - crate_anim_last_update > 100:
                        crate_anim_frame_index = min(crate_anim_frame_index + 1, len(frames)-1)
                        crate_anim_last_update = now
                    icon = frames[crate_anim_frame_index]
                else:
                    icon = modal_heart_sprite if active_popup.get("crate_type") == "Heart" else modal_skull_sprite

                icon_bottom = m_rect.top + 80
                if icon:
                    icon_rect = icon.get_rect(center=(m_rect.centerx, m_rect.top + 80 + (icon.get_height() // 2)))
                    screen.blit(icon, icon_rect)
                    icon_bottom = icon_rect.bottom
                
                y_offset = icon_bottom + 35
                for line in active_popup["lines"]:
                    line_surf = font_small.render(line, True, (229, 229, 234))
                    screen.blit(line_surf, line_surf.get_rect(center=(m_rect.centerx, y_offset)))
                    y_offset += 30

                btn_rect = pygame.Rect(m_rect.centerx - int(confirm_btn_width * 0.4), m_rect.bottom - 30 - confirm_btn_height, int(confirm_btn_width * 0.8), confirm_btn_height)
                draw_button(screen, btn_rect, active_popup["btn_text"], font_small, override_type="button_standard.png")

            else:
                draw_panel(screen, modal_rect)
                title_surf = font_medium.render(active_popup["title"], True, (255, 215, 0))
                screen.blit(title_surf, title_surf.get_rect(center=(modal_rect.centerx, modal_rect.top + 30)))

                y_offset = modal_rect.top + 75
                for line in active_popup["lines"]:
                    line_surf = font_small.render(line, True, (229, 229, 234))
                    screen.blit(line_surf, line_surf.get_rect(center=(modal_rect.centerx, y_offset)))
                    y_offset += 28

                draw_button(screen, modal_close_rect, active_popup["btn_text"], font_small, override_type="button_standard.png")

        if not active_popup and game_state != "THRONE_CRACK" and game_state != "INTRO" and game_state != "HOME_MENU":
            if home_sprite: 
                screen.blit(home_sprite, home_btn_rect.topleft)
            else:
                draw_button(screen, home_btn_rect, "Menu", font_small, override_type="button_standard.png")

        await asyncio.sleep(0)
        pygame.display.flip()
        clock.tick(30) 


async def main():
    # Pygbag wrapper: surface any startup/runtime error on screen
    # instead of a silent gray canvas, so a screenshot shows the traceback.
    try:
        await _game_main()
    except BaseException:
        import traceback
        err = traceback.format_exc()
        print(err)
        try:
            s = pygame.display.set_mode((480, 800))
            pygame.display.set_caption("GAME ERROR")
            s.fill((0, 0, 0))
            try:
                font = pygame.font.Font(None, 20)
            except Exception:
                font = pygame.font.SysFont("monospace", 16)
            y = 8
            for line in err.split("\n")[:36]:
                try:
                    surf = font.render(line[:76], True, (255, 90, 90))
                    s.blit(surf, (8, y))
                except Exception:
                    pass
                y += 20
                if y > 780:
                    break
            pygame.display.flip()
        except Exception:
            pass
        while True:
            await asyncio.sleep(1)

# Pygbag entry point. asyncio.run is NON-BLOCKING on pygame-wasm:
# code after this line runs BEFORE main() starts, so NOTHING may
# follow it -- especially not pygame.quit() / sys.exit(), which used
# to run before the game started and kill it.
asyncio.run(main())
