import os
_base = os.path.dirname(__file__) if '__file__' in globals() else '.'
_gpath = os.path.join(_base, 'game.py')
_src = open(_gpath).read()
_g = {'__name__': '__main__', '__file__': _gpath}
exec(compile(_src, _gpath, 'exec'), _g)
